<template lang="html">
    <div class="detail">
        <el-row>
          <el-col :span="14" :push="5">
            <p class="all-class-top">主题演讲</p>
          </el-col>
        </el-row>
        <el-row>
          <el-col :span="14" :push="5">
          <div class="detail-top">
            <div class="detail-top-first"></div>
            <div class="detail-top-second">
              <div class="detail-name">专题出品人：XXX </div>
              <div class="detail-job">腾讯 计费平台部总监</div>
              <div class="detail-content">正文</div>
            </div>
           </div>
          </el-col>
        </el-row>
         <el-row>
          <el-col :span="14" :push="5">
            <p class="all-class-top" style="margin-top: 5%">专题1</p>
            <p class="expert-content">我们坚持重视新媒体、用好新媒体，发挥新媒体力量，为广大读者和提供更专业、更有效、更有力的传播 服务，海量信息和深度资讯充分融通，打造优质新媒体联合传播平台。 </p>
          </el-col>
        </el-row>
        <el-row>
          <el-col :span="14" :push="5">
          <div class="detail-top">
            <div class="detail-top-left">
               <div class="header"></div>
               <div class="detail-name">王松键</div>
               <div class="detail-content">腾讯</div>
               <div class="detail-content">计费平台部总监</div>
             </div>
            <div class="detail-top-right">
              <div class="content">
                <div class="detail-name">内容1 </div>
                <div class="detail-content">我们坚持重视新媒体、用好新媒体，发挥新媒体力量，为广大读者和 提供更专业、更有效、更有力的传播服务，海量信息和深度资讯充分 融通，打造优质新媒体联合传播平台。</div>
              </div>
              <div class="content">
                <div class="detail-name">内容1 </div>
                <div class="detail-content">我们坚持重视新媒体、用好新媒体，发挥新媒体力量，为广大读者和 提供更专业、更有效、更有力的传播服务，海量信息和深度资讯充分 融通，打造优质新媒体联合传播平台。</div>
              </div>
              <div class="content">
                <div class="detail-name">内容1 </div>
                <div class="detail-content">我们坚持重视新媒体、用好新媒体，发挥新媒体力量，为广大读者和 提供更专业、更有效、更有力的传播服务，海量信息和深度资讯充分 融通，打造优质新媒体联合传播平台。</div>
              </div>
              <div class="content">
                <div class="detail-name">内容1 </div>
                <div class="detail-content">我们坚持重视新媒体、用好新媒体，发挥新媒体力量，为广大读者和 提供更专业、更有效、更有力的传播服务，海量信息和深度资讯充分 融通，打造优质新媒体联合传播平台。</div>
              </div>
            </div>
           </div>
          </el-col>
        </el-row>
        <div class="qingke_footer">
          <el-row>
          <el-col :span="16" :push="4">
            <el-row>
              <el-col :span="24"><div class="grid-content">
              <div>
                  <img src="../assets/images/logo.png" alt="" style="height: 5rem;width:rem;padding-top: 2rem">
               </div>
              </div></el-col>
            </el-row>
           </el-col>
        </el-row>
        <el-row>
          <el-col :span="16" :push="4">
            <el-row type="flex" justify="space-around">
              <el-col :span="24"><div class="grid-content qingke_footer_word">
              <p>
              <span><img src="" alt=""></span>
              <span class="convention_bottom">175 66666 666</span>
              </p>
              <p>
              <span><img src="" alt=""></span>
              <span class="convention_bottom">上海市 长宁区</span>
              </p>
              <p>
              <span><img src="" alt=""></span>
              <span class="convention_bottom">GHRLIB@XX.COM</span>
              </p>
              </div></el-col>

              <el-col :span="24"><div class="grid-content qingke_footer_word">
              <p>旗下品牌：</p>
              <p>
                <span><img src="../assets/images/weiXin.png" alt="" style="height: 2rem;width:3rem;"></span>
                <span><img src="../assets/images/weiXin.png" alt="" style="height: 2rem;width:3rem;"></span>
              </p>
              <p>
                <span><img src="../assets/images/weiXin.png" alt="" style="height: 2rem;width:3rem;"></span>
                <span><img src="../assets/images/weiXin.png" alt="" style="height: 2rem;width:3rem;"></span>
              </p>
              <p>
                <span><img src="../assets/images/weiXin.png" alt="" style="height: 2rem;width:3rem;"></span>
                <span><img src="../assets/images/weiXin.png" alt="" style="height: 2rem;width:3rem;"></span>
              </p>
              </div></el-col>

              <el-col :span="24"><div class="grid-content qingke_footer_word">
              <p>在线学习：</p>
              <p><img src="../assets/images/weiXin.png" alt=""></p>
              <p><img src="../assets/images/weiXin.png" alt=""></p>
              <p><img src="../assets/images/weiXin.png" alt=""></p>
              </div></el-col>
              <el-col :span="24"><div class="grid-content qingke_footer_word constant">
              <p>联系电话：</p>
              <p>培训业务</p>
              <p>微咨询</p>
              <p>在线学习</p>
              <p>广告合作</p>
              <p>市场合作</p>
              <p>加入我们</p>
              </div></el-col>
              <el-col :span="24"><div class="grid-content qingke_footer_word">
              <p>市场合作：</p>
              <p>市场合作：</p>
              </div></el-col>
            </el-row>
           </el-col>
        </el-row>
        </div>
    </div>
</template>

<script>
export default {}
</script>

<style lang="css" scoped>
  .all-class-top{
    font-size: 2.5rem;
    font-weight: 600;
    margin-top: 10rem;
  }
  .detail-top{
    width:100%;
    background-color: #f2f2f2;
    display: flex;
    justify-content: flex-start;
    padding:1rem 0.5rem;
  }
  .detail-top-first{
    height:10rem;
    width:10rem;
    background-color: orangered;
    border-radius: 50%;
    margin-right: 0.5rem;
  }
  .detail-name{
    font-size: 2rem;
    font-weight: 600;
  }
  .detail-job{
    font-size: 1.4rem;
    color: #565656;
  }
  .detail-content{
    font-size: 1.4rem;
    color: #565656;
  }
  .expert-content{
    font-size: 1.4rem;
    color: #565656;
  }
  .detail-top-left{
    text-align: center;
    margin: auto 2rem;
  }
  .header{
    height:8rem;
    width:8rem;
    background-color: orangered;
    border-radius: 50%;
  }
  .detail-top-right{
    padding:0 5% 5% 0;
  }
  .content{
    margin-top: 5%;
    margin-left: 5%;
  }
  .qingke_footer{
    background-color: #222222;
    margin-top: 1%;
  }
  .qingke_footer_word>p:nth-child(1){
    font-size: 1.4rem;
    color: #ffffff;
  }
  .qingke_footer_word>p{
    color: #ffffff;
  }
  .convention_bottom{
    font-size: 1.4rem;
  }
  .constant>p{
    margin-top: 0.5rem;
  }
</style>
