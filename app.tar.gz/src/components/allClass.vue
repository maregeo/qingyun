<template lang="html">
    <div class="allClass">
        <el-row>
          <el-col :span="14" :push="5">
            <p class="all-class-top">主题演讲</p>
          </el-col>
        </el-row>
        <el-row>
          <el-col :span="14" :push="5">
          <div class="class-top">
            <p class="class-top-first">标题</p>
            <p class="class-top-second">副标题</p>
           </div>
          </el-col>
        </el-row>
        <el-row>
          <el-col :span="14" :push="5">
            <el-row>
              <el-col :span="8">
                <div class="class-card" @click="jumpDetail">
                  <div class="class-card-first">
                    <div class="pic"></div>
                    <div class="name">王松键</div>
                    <div class="company">腾讯</div>
                    <div class="job">计算机平台合作总监</div>
                  </div>
                  <div class="class-card-second"></div>
                  <div class="class-card-third">
                    <div class="title">标题</div>
                    <div class="lastTitle">副标题</div>
                  </div>
                </div>
              </el-col>
              <el-col :span="8">
                <div class="class-card">
                  <div class="class-card-first">
                    <div class="pic"></div>
                    <div class="name">王松键</div>
                    <div class="company">腾讯</div>
                    <div class="job">计算机平台合作总监</div>
                  </div>
                  <div class="class-card-second"></div>
                  <div class="class-card-third">
                    <div class="title">标题</div>
                    <div class="lastTitle">副标题</div>
                  </div>
                </div>
              </el-col>
              <el-col :span="8">
                <div class="class-card">
                  <div class="class-card-first">
                    <div class="pic"></div>
                    <div class="name">王松键</div>
                    <div class="company">腾讯</div>
                    <div class="job">计算机平台合作总监</div>
                  </div>
                  <div class="class-card-second"></div>
                  <div class="class-card-third">
                    <div class="title">标题</div>
                    <div class="lastTitle">副标题</div>
                  </div>
                </div>
              </el-col>
            </el-row>
          </el-col>
        </el-row>
        <el-row>
          <el-col :span="14" :push="5">
            <p class="all-class-top" style="margin-top: -1rem">主题演讲</p>
          </el-col>
        </el-row>
        <el-row>
          <el-col :span="14" :push="5">
          <div class="class-top">
            <p class="class-top-first">标题</p>
            <p class="class-top-second">副标题</p>
           </div>
          </el-col>
        </el-row>
        <el-row>
          <el-col :span="14" :push="5">
            <el-row>
              <el-col :span="8">
                <div class="class-card">
                  <div class="class-card-first">
                    <div class="pic"></div>
                    <div class="name">王松键</div>
                    <div class="company">腾讯</div>
                    <div class="job">计算机平台合作总监</div>
                  </div>
                  <div class="class-card-second"></div>
                  <div class="class-card-third">
                    <div class="title">标题</div>
                    <div class="lastTitle">副标题</div>
                  </div>
                </div>
              </el-col>
              <el-col :span="8">
                <div class="class-card">
                  <div class="class-card-first">
                    <div class="pic"></div>
                    <div class="name">王松键</div>
                    <div class="company">腾讯</div>
                    <div class="job">计算机平台合作总监</div>
                  </div>
                  <div class="class-card-second"></div>
                  <div class="class-card-third">
                    <div class="title">标题</div>
                    <div class="lastTitle">副标题</div>
                  </div>
                </div>
              </el-col>
              <el-col :span="8">
                <div class="class-card">
                  <div class="class-card-first">
                    <div class="pic"></div>
                    <div class="name">王松键</div>
                    <div class="company">腾讯</div>
                    <div class="job">计算机平台合作总监</div>
                  </div>
                  <div class="class-card-second"></div>
                  <div class="class-card-third">
                    <div class="title">标题</div>
                    <div class="lastTitle">副标题</div>
                  </div>
                </div>
              </el-col>
            </el-row>
          </el-col>
        </el-row>
        <el-row>
          <el-col :span="14" :push="5">
            <p class="all-class-top" style="margin-top: -1rem">主题演讲</p>
          </el-col>
        </el-row>
        <el-row>
          <el-col :span="14" :push="5">
          <div class="class-top">
            <p class="class-top-first">标题</p>
            <p class="class-top-second">副标题</p>
           </div>
          </el-col>
        </el-row>
        <el-row>
          <el-col :span="14" :push="5">
            <el-row>
              <el-col :span="8">
                <div class="class-card">
                  <div class="class-card-first">
                    <div class="pic"></div>
                    <div class="name">王松键</div>
                    <div class="company">腾讯</div>
                    <div class="job">计算机平台合作总监</div>
                  </div>
                  <div class="class-card-second"></div>
                  <div class="class-card-third">
                    <div class="title">标题</div>
                    <div class="lastTitle">副标题</div>
                  </div>
                </div>
              </el-col>
              <el-col :span="8">
                <div class="class-card">
                  <div class="class-card-first">
                    <div class="pic"></div>
                    <div class="name">王松键</div>
                    <div class="company">腾讯</div>
                    <div class="job">计算机平台合作总监</div>
                  </div>
                  <div class="class-card-second"></div>
                  <div class="class-card-third">
                    <div class="title">标题</div>
                    <div class="lastTitle">副标题</div>
                  </div>
                </div>
              </el-col>
              <el-col :span="8">
                <div class="class-card">
                  <div class="class-card-first">
                    <div class="pic"></div>
                    <div class="name">王松键</div>
                    <div class="company">腾讯</div>
                    <div class="job">计算机平台合作总监</div>
                  </div>
                  <div class="class-card-second"></div>
                  <div class="class-card-third">
                    <div class="title">标题</div>
                    <div class="lastTitle">副标题</div>
                  </div>
                </div>
              </el-col>
            </el-row>
          </el-col>
        </el-row>
        <div class="qingke_footer">
          <el-row>
          <el-col :span="16" :push="4">
            <el-row>
              <el-col :span="24"><div class="grid-content">
              <div>
                  <img src="../assets/images/logo.png" alt="" style="height: 5rem;width:rem;padding-top: 2rem">
               </div>
              </div></el-col>
            </el-row>
           </el-col>
        </el-row>
        <el-row>
          <el-col :span="16" :push="4">
            <el-row type="flex" justify="space-around">
              <el-col :span="24"><div class="grid-content qingke_footer_word">
              <p>
              <span><img src="" alt=""></span>
              <span class="convention_bottom">175 66666 666</span>
              </p>
              <p>
              <span><img src="" alt=""></span>
              <span class="convention_bottom">上海市 长宁区</span>
              </p>
              <p>
              <span><img src="" alt=""></span>
              <span class="convention_bottom">GHRLIB@XX.COM</span>
              </p>
              </div></el-col>

              <el-col :span="24"><div class="grid-content qingke_footer_word">
              <p>旗下品牌：</p>
              <p>
                <span><img src="../assets/images/weiXin.png" alt="" style="height: 2rem;width:3rem;"></span>
                <span><img src="../assets/images/weiXin.png" alt="" style="height: 2rem;width:3rem;"></span>
              </p>
              <p>
                <span><img src="../assets/images/weiXin.png" alt="" style="height: 2rem;width:3rem;"></span>
                <span><img src="../assets/images/weiXin.png" alt="" style="height: 2rem;width:3rem;"></span>
              </p>
              <p>
                <span><img src="../assets/images/weiXin.png" alt="" style="height: 2rem;width:3rem;"></span>
                <span><img src="../assets/images/weiXin.png" alt="" style="height: 2rem;width:3rem;"></span>
              </p>
              </div></el-col>

              <el-col :span="24"><div class="grid-content qingke_footer_word">
              <p>在线学习：</p>
              <p><img src="../assets/images/weiXin.png" alt=""></p>
              <p><img src="../assets/images/weiXin.png" alt=""></p>
              <p><img src="../assets/images/weiXin.png" alt=""></p>
              </div></el-col>
              <el-col :span="24"><div class="grid-content qingke_footer_word constant">
              <p>联系电话：</p>
              <p>培训业务</p>
              <p>微咨询</p>
              <p>在线学习</p>
              <p>广告合作</p>
              <p>市场合作</p>
              <p>加入我们</p>
              </div></el-col>
              <el-col :span="24"><div class="grid-content qingke_footer_word">
              <p>市场合作：</p>
              <p>市场合作：</p>
              </div></el-col>
            </el-row>
           </el-col>
        </el-row>
        </div>
    </div>
</template>

<script>
export default {
  methods:{
  jumpDetail(){
    this.$router.push('/detail')
  },
}
}
</script>

<style lang="css" scoped>
  .all-class-top{
    font-size: 2.5rem;
    font-weight: 600;
    margin-top: 10rem;
  }
  .class-top{
    background-color: #f2f2f2;
    padding: 0.5rem 0.5rem 1rem 0.5rem;
  }
  .class-top-first{
    font-size: 2.5rem;
    color: #565656;
  }
  .class-top-second{
    font-size: 1.4rem;
    color:#565656;
  }
  .class-card{
    display: flex;
    width:90%;
    margin: 0 auto;
    justify-content: flex-start;
    background-color: #f2f2f2;
    padding:1rem 0.5rem;
  }
  .class-card-first{
    text-align: center;
  }
  .pic{
    height:5rem;
    width:5rem;
    margin: 0 auto;
    background-color: orangered;
    border-radius: 50%;
  }
  .name{
    font-size: 1.4rem;
    font-weight: 600;
  }
  .company{
    font-size: 1.0rem;
    color: #565656;
  }
  .job{
    font-size: 1.0rem;
    color: #565656;
  }
  .class-card-second{
    border:0.1rem solid #565656;
    height:8rem;
    margin: 1rem 0.5rem;
  }
  .class-card-third{
    margin: 1rem 0.5rem;
  }
  .title{
    font-size: 1.6rem;
    color: #565656;
  }
  .lastTitle{
    font-size: 1.2rem;
    color: #565656;
  }
  .qingke_footer{
    background-color: #222222;
    margin-top: 1%;
  }
  .qingke_footer_word>p:nth-child(1){
    font-size: 1.4rem;
    color: #ffffff;
  }
  .qingke_footer_word>p{
    color: #ffffff;
  }
  .convention_bottom{
    font-size: 1.4rem;
  }
  .constant>p{
    margin-top: 0.5rem;
  }
</style>
