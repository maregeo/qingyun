<template lang="html">
    <div class="ask">
        <el-row>
          <el-col :span="24"><div class="grid-content bg-purple-dark school_top">
            <!--<xuetangimg src="../assets/images/a1.jpg" alt="" style="width:100%; height: 100vh;">-->
            <p>内训与咨询</p>
            <p>氢云商学连接全国十几万名培训管理者， 云集华为、阿里、腾讯、百度、GE、IBM 等众多国内外知名标杆企业，以“行业对标， 量身定制”为特色，根据企业不同发展阶段 和实际需求，制订符合其发展要求的内训与 咨询方案。服务形式包括内训、微咨询、入 企咨询辅导、常年顾问服务四大类。</p>
            <el-row class="qingKe_top">
          <el-col :span="4"><div class="grid-content bg-purple-light"></div></el-col>
          <el-col :span="5"><div class="qingKe_top_left">企业大学
          </div></el-col>
          <el-col :span="11"><div class="qingKe_top_right">
            <div>M-Learning解决方案</div>
            <div>定制内训</div>
            <div >管理咨询</div>
          </div></el-col>
          <el-col :span="4"><div class="grid-content bg-purple-light"></div></el-col>
        </el-row>
          </div></el-col>
        </el-row>
        <div class="sy_car_third">
        <p style="margin-bottom: 0.5%">M-Learning</p>
        <p style="margin-bottom: 1%">解决方案</p>
        <p style="margin-bottom: 1%">氢学堂，一体化企业移动商学院解决方案专家，由原华为、时代光华、 行动成功高管团队联合打造。氢学堂以SAAS平台为载体， 管理咨询服务为支撑，兼顾运营效率与成果落地， 助力每一家企业便捷高效的建立专属的内部商学院， 让人才培养更系统、实时、实效、落地。</p>
        <el-row>
              <el-col :span="24"><div class="grid-content">
              <div>
                  <img src="../assets/images/cloud.png" alt="" style="width:40%;">
               </div>
              </div></el-col>
            </el-row>
      </div>
      <div class="education">
        <p>定制内训</p>
        <ul>
           <li>战略与变革：战略解码工作坊、大数据与流程绩效管理、 基于流程的企业运营管理、组织变革之战略罗盘</li>
           <li>HR提升与转型：人才盘点与人才梯队建设、OKR敏捷绩效管理、 企业文化建设与落地、HRBP模式的构建与运作</li>
           <li>人才发展：E9关键人才管理方案、教练型内训师、合伙人136模式、 企业微课系统化开发与应用</li>
           <li>领导力：领导自我、领导员工、领导经理、领导组织 </li>
           <li>互联网转型：BAT的大数据和云服务战略、O2O对传统商业模式的 颠覆、移动互联时代的“去中心化法则”、您必须知道的用户体验和 产品设计 </li>
           <li>学习标杆：对标华为、对标阿里巴巴、对标腾讯、对标海尔</li>
           <li>营销管理：销售精英实战技能训练、大客户销售策略、渠道开发与 经销商、金牌店长全能训练 </li>
           <li>职场技能：高效能人士的七个习惯、Oﬃce软件技能提升、商务 演讲与表达、思维导图的职场</li>
        </ul>
        <img src="../assets/images/parent.png" alt="" style="width: 40%">
      </div>
      <div class="sy_car_third">
        <p style="margin-bottom: 0.5%">管理咨询 </p>
        <p style="margin-bottom: 1%;font-size: 2rem">200多位国内顶级咨询顾问、知名专家 提供专业系统的管理咨询解决方案和管理智慧 800多家行业领先企业 大型企业管理咨询经验总结 保证管理方案有效落地运用</p>

        <el-row>
              <el-col :span="10" :push="7"><div class="grid-content bg-purple-light">
                <el-row>
                  <el-col :span="8" :xs="24" :sm="8">
                    <div class="grid-content bg-purple-light">
                      <div class="consult">
                        <img src="../assets/images/one-man.png" alt="">
                        <p>微咨询</p>
                      </div>
                    </div>
                  </el-col>
                  <el-col :span="8" :xs="24" :sm="8">
                    <div class="grid-content bg-purple-light">
                      <div class="coach">
                        <img src="../assets/images/two-person.png" alt="">
                        <p>入企咨询辅导</p>
                      </div>
                    </div>
                  </el-col>
                  <el-col :span="8" :xs="24" :sm="8">
                    <div class="grid-content bg-purple-light">
                      <div class="counselor">
                        <img src="../assets/images/one-women.png" alt="">
                        <p>常年顾问服务</p>
                      </div>
                    </div>
                  </el-col>
                </el-row>
             </div></el-col>
            </el-row>
      </div>
    <div class="qingke_footer">
          <el-row>
          <el-col :span="16" :push="4">
            <el-row>
              <el-col :span="24"><div class="grid-content">
              <div>
                  <img src="../assets/images/logo.png" alt="" style="height: 5rem;width:rem;padding-top: 2rem">
               </div>
              </div></el-col>
            </el-row>
           </el-col>
        </el-row>
        <el-row>
          <el-col :span="16" :push="4">
            <el-row type="flex" justify="space-around">
              <el-col :span="24"><div class="grid-content qingke_footer_word">
              <p>
              <span><img src="" alt=""></span>
              <span class="convention_bottom">175 66666 666</span>
              </p>
              <p>
              <span><img src="" alt=""></span>
              <span class="convention_bottom">上海市 长宁区</span>
              </p>
              <p>
              <span><img src="" alt=""></span>
              <span class="convention_bottom">GHRLIB@XX.COM</span>
              </p>
              </div></el-col>

              <el-col :span="24"><div class="grid-content qingke_footer_word">
              <p>旗下品牌：</p>
              <p>
                <span><img src="../assets/images/weiXin.png" alt="" style="height: 2rem;width:3rem;"></span>
                <span><img src="../assets/images/weiXin.png" alt="" style="height: 2rem;width:3rem;"></span>
              </p>
              <p>
                <span><img src="../assets/images/weiXin.png" alt="" style="height: 2rem;width:3rem;"></span>
                <span><img src="../assets/images/weiXin.png" alt="" style="height: 2rem;width:3rem;"></span>
              </p>
              <p>
                <span><img src="../assets/images/weiXin.png" alt="" style="height: 2rem;width:3rem;"></span>
                <span><img src="../assets/images/weiXin.png" alt="" style="height: 2rem;width:3rem;"></span>
              </p>
              </div></el-col>

              <el-col :span="24"><div class="grid-content qingke_footer_word">
              <p>在线学习：</p>
              <p><img src="../assets/images/weiXin.png" alt=""></p>
              <p><img src="../assets/images/weiXin.png" alt=""></p>
              <p><img src="../assets/images/weiXin.png" alt=""></p>
              </div></el-col>
              <el-col :span="24"><div class="grid-content qingke_footer_word constant">
              <p>联系电话：</p>
              <p>培训业务</p>
              <p>微咨询</p>
              <p>在线学习</p>
              <p>广告合作</p>
              <p>市场合作</p>
              <p>加入我们</p>
              </div></el-col>
              <el-col :span="24"><div class="grid-content qingke_footer_word">
              <p>市场合作：</p>
              <p>市场合作：</p>
              </div></el-col>
            </el-row>
           </el-col>
        </el-row>
        </div>
    </div>
</template>

<script>
export default {}
</script>

<style lang="css" scoped>
  .school_top{
    height:100vh;
    width:100%;
    background-image: url("../assets/images/ask.jpg");
    background-size: 100% 100%;
  }
  .school_top>p:nth-child(1){
    font-size: 6rem;
    color: #ffbc08;
    position: absolute;
    top:30%;
    left: 30%;
  }
  .school_top>p:nth-child(2){
    font-size: 2rem;
    width:25%;
    position: absolute;
    color: #ffffff;
    top:45%;
    left: 30%;
  }
  .school_top>p:nth-child(3){
    color: #ffffff;
    font-size: 3rem;
    position: absolute;
    top:70%;
    left: 30%;
    left: 30%;
    vertical-align: top;
  }

  .qingKe_top{
    position: relative;
    background-color: #f4f4f4;
    height: 6rem;
    line-height: 6rem;
    border-bottom: 0.1rem solid gray;
    top:95%;
    z-index: 666;
  }
  .qingKe_top_left{
    font-size: 3rem;
    font-weight: 600;
  }
  .qingKe_top_right{
    display: flex;
    margin-top: 2rem;
  }
  .qingKe_top_right>div{
    text-align: center;
    width:25%;
    line-height: 2rem;
    font-size: 1.4rem;
    height: 2rem;
    border-right: 0.1rem solid gray;
    justify-content: space-around;
  }
  .sy_car_third>p:nth-child(2){
    color: #000000;
    font-size: 6rem;
  }
  .sy_car_third>p:nth-child(3){
    font-size: 2rem;
    color: #ffffff;
    margin-left: 25%;
    margin-right: 25%;
    color: #595959;
  }
  .education{
    background-color: #222222;
    text-align: center;
  }
  .education>p:nth-child(1){
    padding: 0 auto;
    color: #ffffff;
    font-size: 6rem;
    padding-top: 5%;
  }
  .education>ul{
    font-size: 2rem;
    margin-top: 2%;
    color: #FCD281;
    margin-left: 25%;
    margin-right: 25%;
    text-align: left;
  }
  .consult{
    width:80%;
    margin: 0 auto;
    padding: 2rem 1rem;
    height:20rem;
    background-color: #595959;
    border-radius: 2rem;
  }
  .consult p{
    font-size: 3rem;
    color: #ffffff;
    margin-top: 1rem;
  }
  .coach{
    width:80%;
    margin: 0 auto;
    padding:2rem 1rem;
    height:20rem;
    background-color: #595959;
    border-radius: 2rem;
  }
  .coach p{
    font-size: 3rem;
    color: #ffffff;
    margin-top: 1rem;
  }
  .counselor{
    width:80%;
    margin: 0 auto;
    padding: 2rem 1rem;
    height:20rem;
    background-color: #595959;
    border-radius: 2rem;
  }
  .counselor p{
    font-size: 3rem;
    color: #ffffff;
    margin-top: 1rem;
  }
  .qingke_footer{
    background-color: #222222;
    padding-top: 2%;
  }
  .qingke_footer_word>p:nth-child(1){
    font-size: 1.4rem;
    color: #ffffff;
  }
  .qingke_footer_word>p{
    color: #ffffff;
  }
</style>
