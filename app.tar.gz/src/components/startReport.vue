<template lang="html">
    <div class="startReport">
        <el-row>
          	<el-col :span="24"><div class="grid-content bg-purple-dark">
		  		<img src="../assets/images/readMax.jpg" class="v-success-img"/>
            <!--<xuetangimg src="../assets/images/a1.jpg" alt="" style="width:100%; school_top height: 100vh;">-->
			<div class="v-start-wrapp">
				<div class="v-start-hide">
					<p>GMTC</p>
					<p>全球移动大会 </p>
					<p>氢云新媒体矩阵包括环球人力资源智库、 解读标杆、每天学点HR、管理定见等优 质微信公众号，各具特色，功能互补， 错位发展。</p>
				</div>
				<div class="v-start-bj">
					<div class="v-statr-w">
						<div class="li">
							<p>大会参与人数</p>
							<p>1000+</p>
						</div>
						<div class="li">
							<p>专家参与人数</p>
							<p>200+</p>
						</div>
						<div class="li">
							<p>参与企业</p>
							<p>200+</p>
						</div>
						<div class="li">
							<p>10年以上工作经验</p>
							<p>90%</p>
						</div>
					</div>
				</div>
			</div>
            <el-row class="qingKe_top">
				<el-col :span="7">
					<div class="qingKe_top_left" style="text-align:right;">GMTC全球移动大会</div>
				</el-col>
				<el-col :span="17">
					<div class="qingKe_top_right">
						<div>课程简介</div>
						<div>现场照片</div>
						<div >活动讲师</div>
						<div >学院感言</div>
						<div >参训集团</div>
					</div>
				</el-col>
          	</el-row>
          </div></el-col>
        </el-row>
        <el-row>
          	<el-col :span="24"><div class="grid-content bg-purple-dark" >
            	<div class="sy_car_third">
              		<p>成功案例 </p>
             		<p>我们坚持重视新媒体、用好新媒体，发挥新媒体力量， 为广大读者和提供更专业、更有效、更有力的传播服务， 海量信息和深度资讯充分融通，打造优质新媒体联合传播平台。</p>
            	</div>
          		</div>
			</el-col>
        </el-row>
        <el-row class="v-statr-row">
          	<el-col :span="14" :push="5" class="v-statr-col">
            	<el-row>
              		<el-col :span="8" :xs="24">
						<div class="grid-content card">
							<div class="card-card">
								<div class="card-card-top">标题</div>
								<div class="card-line"></div>
								<div class="content">正文</div>
							</div>
              			</div>
					</el-col>
              		<el-col :span="8" :xs="24">
					  	<div class="grid-content card">
							<div class="card-card">
								<div class="card-card-top">标题</div>
								<div class="card-line"></div>
								<div class="content">正文</div>
							</div>
              			</div>
			 		</el-col>
					<el-col :span="8" :xs="24">
						<div class="grid-content card">
							<div class="card-card">
								<div class="card-card-top">标题</div>
								<div class="card-line"></div>
								<div class="content">正文</div>
							</div>
						</div>
					</el-col>
					<el-col :span="8" :xs="24">
						<div class="grid-content card">
							<div class="card-card">
								<div class="card-card-top">标题</div>
								<div class="card-line"></div>
								<div class="content">正文</div>
							</div>
						</div>
					</el-col>
					<el-col :span="8" :xs="24">
						<div class="grid-content card">
							<div class="card-card">
								<div class="card-card-top">标题</div>
								<div class="card-line"></div>
								<div class="content">正文</div>
							</div>
						</div>
					</el-col>
					<el-col :span="8" :xs="24">
						<div class="grid-content card">
							<div class="card-card">
								<div class="card-card-top">标题</div>
								<div class="card-line"></div>
								<div class="content">正文</div>
							</div>
						</div>
					</el-col>
					<el-col :span="24">
						<p class="check-all-class" @click="jumpAllClass">查看所有课程</p>
					</el-col>
            	</el-row>
          	</el-col>
		</el-row>
        <div class="sy_car_second">
        <p>现场照片</p>
        <p>我们坚持重视新媒体、用好新媒体，发挥新媒体力量， 为广大读者和提供更专业、更有效、更有力的传播服务， 海量信息和深度资讯充分融通，打造优质新媒体联合传播平台。</p>
        <el-row class="v-statr-row">
          <el-col :span="14" :push="5" class="v-statr-col">
            <el-row>
              <el-col :span="6">
                <div class="picture"></div>
              </el-col>
              <el-col :span="6">
                <div class="picture"></div>
              </el-col>
              <el-col :span="6">
                <div class="picture"></div>
              </el-col>
              <el-col :span="6">
                <div class="picture"></div>
              </el-col>
            </el-row>
            <el-row>
              <el-col :span="6">
                <div class="picture"></div>
              </el-col>
              <el-col :span="6">
                <div class="picture"></div>
              </el-col>
              <el-col :span="6">
                <div class="picture"></div>
              </el-col>
              <el-col :span="6">
                <div class="picture"></div>
              </el-col>
            </el-row>
            <el-row>
              <el-col :span="6">
                <div class="picture"></div>
              </el-col>
              <el-col :span="6">
                <div class="picture"></div>
              </el-col>
              <el-col :span="6">
                <div class="picture"></div>
              </el-col>
              <el-col :span="6">
                <div class="picture"></div>
              </el-col>
            </el-row>
            <el-row>
              <el-col :span="6">
                <div class="picture"></div>
              </el-col>
              <el-col :span="6">
                <div class="picture"></div>
              </el-col>
              <el-col :span="6">
                <div class="picture"></div>
              </el-col>
              <el-col :span="6">
                <div class="picture"></div>
              </el-col>
            </el-row>
          </el-col>
        </el-row>
      </div>
      <div class="sy_car_third">
        	<p>活动讲师</p>
        	<p>我们坚持重视新媒体、用好新媒体，发挥新媒体力量， 为广大读者和提供更专业、更有效、更有力的传播服务， 海量信息和深度资讯充分融通，打造优质新媒体联合传播平台。</p>
        <el-row>
          <el-col :span="14" :push="5" class="v-statr-col">
            <el-row>
              <el-col :span="6">
                <div class="teacher">
                  <div class="teacherFirst" @click="jumpDetail"></div>
                  <div class="teacherSecond">王松键</div>
                  <div class="teacherThird">腾讯</div>
                  <div class="teacherFourth">计费平台部总监</div>
                 </div>
              </el-col>
              <el-col :span="6">
                <div class="teacher">
                  <div class="teacherFirst" @click="jumpDetail"></div>
                  <div class="teacherSecond">王松键</div>
                  <div class="teacherThird">腾讯</div>
                  <div class="teacherFourth">计费平台部总监</div>
                 </div>
              </el-col>
              <el-col :span="6">
                <div class="teacher">
                  <div class="teacherFirst" @click="jumpDetail"></div>
                  <div class="teacherSecond">王松键</div>
                  <div class="teacherThird">腾讯</div>
                  <div class="teacherFourth">计费平台部总监</div>
                 </div>
              </el-col>
              <el-col :span="6">
                <div class="teacher">
                  <div class="teacherFirst" @click="jumpDetail"></div>
                  <div class="teacherSecond">王松键</div>
                  <div class="teacherThird">腾讯</div>
                  <div class="teacherFourth">计费平台部总监</div>
                 </div>
              </el-col>
            </el-row>
                     <el-row>
              <el-col :span="6">
                <div class="teacher">
                  <div class="teacherFirst" @click="jumpDetail"></div>
                  <div class="teacherSecond">王松键</div>
                  <div class="teacherThird">腾讯</div>
                  <div class="teacherFourth">计费平台部总监</div>
                 </div>
              </el-col>
              <el-col :span="6">
                <div class="teacher">
                  <div class="teacherFirst" @click="jumpDetail"></div>
                  <div class="teacherSecond">王松键</div>
                  <div class="teacherThird">腾讯</div>
                  <div class="teacherFourth">计费平台部总监</div>
                 </div>
              </el-col>
              <el-col :span="6">
                <div class="teacher">
                  <div class="teacherFirst" @click="jumpDetail"></div>
                  <div class="teacherSecond">王松键</div>
                  <div class="teacherThird">腾讯</div>
                  <div class="teacherFourth">计费平台部总监</div>
                 </div>
              </el-col>
              <el-col :span="6">
                <div class="teacher">
                  <div class="teacherFirst" @click="jumpDetail"></div>
                  <div class="teacherSecond">王松键</div>
                  <div class="teacherThird">腾讯</div>
                  <div class="teacherFourth">计费平台部总监</div>
                 </div>
              </el-col>
            </el-row>
            <el-col :span="24">
               <p class="check-all-class" @click="jumpDetail">查看所有讲师</p>
              </el-col>
          </el-col>
        </el-row>
      </div>
      <div class="sy_car_second">
        <p>学员感言</p>
        <p>我们坚持重视新媒体、用好新媒体，发挥新媒体力量， 为广大读者和提供更专业、更有效、更有力的传播服务， 海量信息和深度资讯充分融通，打造优质新媒体联合传播平台。</p>
        <el-row class="v-statr-row">
          <el-col :span="14" :push="5" class="v-statr-col">
            <el-row>
              <el-col :span="24">
                <div class="parent-teacher">
                  <div class="parent-teacher-bottom">
                    <div class="teacher-bottom-first"></div>
                    <div class="teacher-bottom-second">王松键</div>
                  </div>
                  <div class="teacher-bottom"></div>
                </div>
              </el-col>
              <el-col :span="24">
                <div class="parent-teacher">
                <div class="teacher-bottom"></div>
                  <div class="parent-teacher-bottom">
                    <div class="teacher-bottom-first"></div>
                    <div class="teacher-bottom-second">王松键</div>
                  </div>
                </div>
              </el-col>
              <el-col :span="24">
                <div class="parent-teacher">
                  <div class="parent-teacher-bottom">
                    <div class="teacher-bottom-first"></div>
                    <div class="teacher-bottom-second">王松键</div>
                  </div>
                  <div class="teacher-bottom"></div>
                </div>
              </el-col>
              <el-col :span="24">
                <div class="parent-teacher">
                <div class="teacher-bottom"></div>
                  <div class="parent-teacher-bottom">
                    <div class="teacher-bottom-first"></div>
                    <div class="teacher-bottom-second">王松键</div>
                  </div>
                </div>
              </el-col>
            </el-row>
          </el-col>
        </el-row>
      </div>
      <div class="sy_car_third">
        <p>百万HR的 共同选择 </p>
        <p>环球人力资源智库（GHR/GHRlib）—— 最具影响力人力资源新媒体， 最好的HR学习地盘；组织学习与人才培养专家，致力于推动中国企业 人力资源效能提升与组织转型。</p>
        <el-row>
          <el-col :span="12" :push="6" class="v-hr">
            <el-row class="v-hello-row">
              <el-col :span="6" :xs="12" :ms="14" :md="12" :lg="6" v-for="item in logos" key="logos" class="v-hr-list">
                <div class="parent">
                  <div class="list_icon">
                    <div><img :src="getImg(item)" alt="" class="v-hr-imgs"></div>
                  </div>
                </div>
              </el-col>
            </el-row>
          </el-col>
        </el-row>
      </div>
      <div class="qingke_footer">
          <el-row>
          <el-col :span="16" :push="4">
            <el-row>
              <el-col :span="24"><div class="grid-content">
              <div>
                  <img src="../assets/images/logo.png" alt="" style="height: 5rem;width:rem;padding-top: 2rem">
               </div>
              </div></el-col>
            </el-row>
           </el-col>
        </el-row>
        <el-row>
          <el-col :span="16" :push="4">
            <el-row type="flex" justify="space-around">
              <el-col :span="24"><div class="grid-content qingke_footer_word">
              <p>
              <span><img src="" alt=""></span>
              <span class="convention_bottom">175 66666 666</span>
              </p>
              <p>
              <span><img src="" alt=""></span>
              <span class="convention_bottom">上海市 长宁区</span>
              </p>
              <p>
              <span><img src="" alt=""></span>
              <span class="convention_bottom">GHRLIB@XX.COM</span>
              </p>
              </div></el-col>

              <el-col :span="24"><div class="grid-content qingke_footer_word">
              <p>旗下品牌：</p>
              <p>
                <span><img src="../assets/images/weiXin.png" alt="" style="height: 2rem;width:3rem;"></span>
                <span><img src="../assets/images/weiXin.png" alt="" style="height: 2rem;width:3rem;"></span>
              </p>
              <p>
                <span><img src="../assets/images/weiXin.png" alt="" style="height: 2rem;width:3rem;"></span>
                <span><img src="../assets/images/weiXin.png" alt="" style="height: 2rem;width:3rem;"></span>
              </p>
              <p>
                <span><img src="../assets/images/weiXin.png" alt="" style="height: 2rem;width:3rem;"></span>
                <span><img src="../assets/images/weiXin.png" alt="" style="height: 2rem;width:3rem;"></span>
              </p>
              </div></el-col>

              <el-col :span="24"><div class="grid-content qingke_footer_word">
              <p>在线学习：</p>
              <p><img src="../assets/images/weiXin.png" alt=""></p>
              <p><img src="../assets/images/weiXin.png" alt=""></p>
              <p><img src="../assets/images/weiXin.png" alt=""></p>
              </div></el-col>
              <el-col :span="24"><div class="grid-content qingke_footer_word constant">
              <p>联系电话：</p>
              <p>培训业务</p>
              <p>微咨询</p>
              <p>在线学习</p>
              <p>广告合作</p>
              <p>市场合作</p>
              <p>加入我们</p>
              </div></el-col>
              <el-col :span="24"><div class="grid-content qingke_footer_word">
              <p>市场合作：</p>
              <p>市场合作：</p>
              </div></el-col>
            </el-row>
           </el-col>
        </el-row>
        </div>
    </div>
</template>

<script>
  export default {
    name: 'startReport',
    data (){
      return{
        logos: [
          'ali.png',
          'tencent.png',
          'qs.png',
          'bayer-01.png',
          'flp.png',
          'ft.png',
          'parker-01.png',
          'liNing.png',
          'nh.png',
          'lianTong.png',
          'meiDi.png',
          'jh.png',
          'sq.png',
          'wangYi.png'
        ]
      }
    },
    methods:{
		getImg(url) {
        	return require(`../assets/images/${url}`)
      	},
      	jumpAllClass(){
        	this.$router.push('/allClass')
      	},
      	jumpDetail(){
        	this.$router.push('/detail')
      	},
    }
}
</script>

<style lang="css" scoped>
	.v-statr-w{
		width:80%;
		margin: auto;
	}
	
	.v-start-wrapp{
		position:absolute;
		top:0;
		left:0;
		width:100%;
		bottom:0;
	}
	.v-success-img{
		width:100%;
	}
  .school_top{
    height:100vh;
    width:100%;
    background-image: url("../assets/images/readMax.jpg");
    background-size: 100% 100%;
  }
  .v-start-hide{
	 text-align:center;
	 font-size:6rem;
	color:#ffbc08;
	 width:50%;
	 margin:20% auto 0;
  }
  .v-start-hide p:last-child{
	   color: #ff772a;
	   font-size:2.5rem;
  }
  .v-start-bj{
	  position:absolute;
	  left:0;
	  bottom:100px;
	  width:100%;
	  background-color: rgba(255,119,42,0.5);

  }
  .v-statr-w{
	  padding:20px 0;
  }
  .v-statr-w .li{
	  width:25%;
	  float:left;
	  text-align:center;
  }
    .v-statr-w .li p{
		padding-bottom:20px;
	}
	.v-statr-w .li p:nth-child(1){
		font-size:3.8rem;
   		 color:#fff;
	}
	 .v-statr-w .li p:nth-child(2){
		font-size:3rem;
   		 color:#333;
		font-weight:bold;
		
	}
  .v-start-hide>div:nth-child(1){
	  /*
    width: 100%;
    position: absolute;
    top: 30%;
    margin-top: -3rem;
    text-align: center;
	 */
  }
  .v-start-hide>div:nth-child(1)>p:nth-child(1){
    font-size: 6rem;
    color: #ffbc08;
  }
  .v-start-hide>div:nth-child(1)>p:nth-child(2){
    font-size: 6rem;
    color: #ffbc08;
  }
  .v-start-hide>div:nth-child(1)>p:nth-child(3){
    font-size: 3rem;
    width:30%;
    color: #ff772a;
    margin: 0 auto;
  }
  .v-start-hide>div:nth-child(2){
    font-size: 2rem;
    width:100%;
    height:10rem;
    background-color: rgba(255,119,42,0.4);
    position: absolute;
    color: #ffffff;
    bottom:10%;
    text-align: center;
  }
  .v-start-hide>div:nth-child(2)>div{
    width:20%;
    margin-top: 2rem;
    display: inline-block;
  }
  .v-start-hide>div:nth-child(2)>div>p:nth-child(2){
    color: #222222;
    font-size: 3rem;
  }
  .v-start-hide>p:nth-child(3){
	  /* 
    color: #ffffff;
    font-size: 3rem;
    position: absolute;
    top:70%;
    left: 30%;
    left: 30%;
    vertical-align: top;
	*/
  }

  .qingKe_top{
    position: relative;
    background-color: #f4f4f4;
    height: 6rem;
    line-height: 6rem;
    border-bottom: 0.1rem solid gray;
    top:95%;
    z-index: 666;
  }
  .qingKe_top_left{
    font-size: 3rem;
    font-weight: 600;
  }
  .qingKe_top_right{
    display: flex;
    margin-top: 2rem;
  }
  .qingKe_top_right>div{
    text-align: center;
    width:20%;
    line-height: 2rem;
    font-size: 1.4rem;
    height: 2rem;
    border-right: 0.1rem solid gray;
    justify-content: space-around;
  }
  .card{
    margin: 0 auto;
    margin-top: 3%;
  }
  .card-card{
    width: 20rem;
    height:20rem;
    margin: 0 auto;
    background-color: #d3dce6;
  }
  .card-card-top{
    font-size: 2rem;
  }
  .card-line{
    width:98%;
    margin: 0 auto;
    border:0.1rem solid #565656;
  }
  .content{
    font-size: 1.4rem;
  }
  .check-all-class{
    margin: 0 auto;
    margin-top: 5%;
    padding: 0.5rem;
    width:9rem;
    color: #ffffff;
    background-color: #565656;
    font-size: 1.4rem;
    border-radius: 1.2rem;
	text-align:center;
  }
  p .check-all-class:hover{
    background-color: #ffffff;
    border:0.1rem solid #565656;
    color: #222222;
  }
  .parent{
    width:100%;
    display: flex;
  }
  .picture{
    height:15rem;
    width:15rem;
    background-color: orangered;
    margin: 0 auto;
  }

  /*.parent>div:nth-child(1){*/
    /*justify-content: space-around;*/
     /*width:59%;*/
     /*background-color: orangered;*/
     /*height:10rem;*/
   /*}*/
  /*.parent>div:nth-child(2){*/
    /*justify-content: space-around;*/
    /*width:29%;*/
    /*background-color: orangered;*/
    /*height:10rem;*/
  /*}*/
  .teacher{
    margin: 0 auto;
    text-align: center;
    margin-top: 5%;
  }
  .teacherFirst{
    height:10rem;
    width:10rem;
    background-color: orangered;
    border-radius: 50%;
    margin: 0 auto;
  }
  .teacherSecond{
    font-size: 2rem;
    font-weight: 600;
  }
  .teacherThird{
    font-size: 1.4rem;
    color:#565656;
  }
  .teacherFourth{
    font-size: 1.4rem;
    color:#565656;
  }
  .parent-teacher{
    display: flex;
    justify-content: space-around;
    margin-bottom: 2%;
  }
  .teacher-bottom-first{
    height:10rem;
    width:10rem;
    background-color: orangered;
    border-radius: 50%;
  }
  .teacher-bottom-second{
    font-size: 2rem;
    color: #ffffff;
  }
  .teacher-bottom{
    width: 80%;
    background-color: #007aff;
    border-radius: 1rem;
  }
  .qingke_footer{
    background-color: #222222;
    margin-top: 1%;
  }
  .qingke_footer_word>p:nth-child(1){
    font-size: 1.4rem;
    color: #ffffff;
  }
  .qingke_footer_word>p{
    color: #ffffff;
  }
  .convention_bottom{
    font-size: 1.4rem;
  }
  .constant>p{
    margin-top: 0.5rem;
  }
  .card-card-top{
	  	height:30px;
	  	line-height:30px;
		text-align:center;
  }
	.sy_car_second>p:nth-child(2){
		padding-bottom:10px;
	}
  	@media screen and (max-width:640px){
		.v-start-hide{
			display:none;
	  	}
		.sy_car_third>p:nth-child(2){
			width:80%;
			margin:0 auto;
			line-height:20px;
		}
		.sy_car_second>p:nth-child(2){
			width:80%;
			margin:0 auto;
			line-height:20px;
		}
		.v-statr-row{
			padding:0 10px;
		}
		.v-statr-col{
			width:100%;
			left:0;
		}
		.v-statr-col .el-col-xs-24,.v-statr-col .el-col-6{
			width:50%;
			padding-right:10px;
			margin-bottom:10px;
		}
		.card-card{
			width:100%;
			height:auto;
		}	
		.content{
			min-height:100px;
		}
		.check-all-class{
			margin-bottom:10px;
		}
		.picture{
			width:100%;
			
		}

		.teacher-bottom-first{
			width:45px;
			height:45px;
			padding:10px;
		}


		.v-hr{
		width:75%;
		left:0;
		margin:0 auto;
		float:none;
	}
	.parent{
		margin-top:10px;
	}
	.list_icon>div{
		width:auto;
		height:auto;
	}
	.list_icon{
		height:auto;
		padding:2px 0;
	}
	.v-hr .v-hr-list .v-hr-imgs{
		width:100%;
		vertical-align:top;
  }
  .list_icon{
    width:100%;
  }
	.sy_car_second{
		padding:20px 0;
		
	}
	.sy_car_third>p:nth-child(1){
		font-size:20px;
	}
	.v-newmt{
		margin-top:20px;
	}
	.bus-tit2{
		font-size:20px!important;
	}
	.sy_car_second>p:nth-child(1){
		font-size:20px;
	}
	.v_about {
		width:75%;
		left:0;
		margin:0 auto;
		float:none;
  	}
  	.v-hello-row .v-hr-list:nth-child(odd){
    	padding-right:5px;
 	}
  	.v-hello-row .v-hr-list:nth-child(even){
    	padding-left:5px;
  	}
		
}
</style>
