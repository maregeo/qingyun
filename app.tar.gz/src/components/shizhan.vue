<template lang="html">
    <div class="zhuanxing">
      <div class="zhuanxing-top">
          <div><img src="../assets/images/minshizhan.png" alt=""></div>
          <div>落地实战系列</div>
        </div>
        <div class="content">
          <table  border="0" cellspacing="0" cellpadding="0">
            <tr>
              <th class="left">主题</th>
              <th>天数</th>
              <th class="right">上榜理由</th>
            </tr>
            <tr>
              <td class="main-head">薪酬体系设计方案班2天1晚-手把手教你搭体系</td>
              <td>2</td>
              <td class="lastCol"rowspan="2">听了那么多薪酬公开课，学会了吗？落地了嘛？花高额咨询费请专家做咨询，有效吗？满意吗？薪酬设计这个牵一发而动全身的问题到底如何解决？唯有培养企业内部的薪酬设计专家，才是最好的解决办法！
              GHR爆款精品公开课2018全新升级方案班现场教，现场学，现场做，现场改导师与顾问全程辅导完完整整教您薪酬咨询的方法与套路实实在在带您在现场做完企业薪酬方案助力您成为企业内部薪酬体系设计专家！</td>

            </tr>
            <tr>
              <td class="main-head">薪酬体系设计现场咨询班-让HR成为企业内部薪酬咨询专家</td>
              <td>6</td>
              <td class="lastCol" ></td>
            </tr>
            <tr>
              <td class="main-head">可复制的绩效模式-绩效管理操作技巧</td>
              <td>2</td>
              <td class="lastCol">企业绩效的有效推进和成果落地一直是HR面临的长期实际问题，究竟如何切实的解决绩效问题，其实关键还是在人身上，尤其是肩负着绩效实际落地推进的直线管理者上。
如何提升绩效意识，如何发现绩效问题，如何辅导下属绩效，如何达成企业绩效目标，本课程以全新的课程设计思路和落地的内容编排逻辑助力企业绩效推进稳步向前。</td>
            </tr>
            <tr>
              <td class="main-head">招聘管理与面试甄选技巧</td>
              <td>2</td>
              <td class="lastCol">在当今竞争日益激烈的商业环境中，企业竞争的核心就是人才的竞争。可是很多企业在招聘人才时，却常陷入困惑。
本课程全面系统地介绍了当代人力资源招聘的核心技术方法；紧密结合企业招聘过程中所面临的关键问题，从有效性、实用性角度提供解决方案。课程以运用为导向，设计丰富的实战案例，通过案例剖析和学员互动，帮助学员掌握招聘选拔的关键技巧，确保其所学能直接用于现实的人才招聘工作中。</td>
            </tr>
            <tr>
              <td class="main-head">培训管理地图TMM-II</td>
              <td>2</td>
              <td class="lastCol">汇聚了世界500强公司和中国一流企业在培训管理领域的最佳实践经验；历时8年研发，5次版本升级，近300期教学锤炼，约10000人/次学习体验；先后被国内众多知名企业引进为内训课程。
本课程系统讲解当下培训管理者如何在企业培训发生巨大变化的情况下，完成自身的转型和岗位业务升级。课程通过学习“4P人才培养模型”及其方法和工具，解决企业低成本、高效率培养各层级人才的系统性方法问题，让企业培训管理和培训实践变得更敏捷和高效。</td>
            </tr>
            <tr>
              <td class="main-head">用设计思维重塑人力资源部</td>
              <td>2</td>
              <td class="lastCol">企业老板对人力资源部门越来越缺乏耐心，平静的水面下暗流涌动。
从事人力资源部门的工作并不等于会做人力资源，缺乏价值导向的人力资源工作繁忙不一定有效果，懂得多并不一定做的好，贴近业务也未必获得认同。拿来主义式的标杆推进和六大模块的分步变革越来越不合时宜。
现在开始，用设计思维重塑人力资源部门，设身处地地以用户为中心。课程现场学习演练人力资源战略和变革系列工具，学会设计落地和后台管理一体的STEP人力资源战略变革方法，打通做什么和怎么做，系统学习设计思维导向的人力资源部门塑造方法，最终帮助业务部门建立自我驱动能力。</td>
            </tr>
          </table>
        </div>
        <footer-bar></footer-bar>
        <!--
        <div class="qingke_footer">
          <el-row>
          <el-col :span="16" :push="4">
            <el-row>
              <el-col :span="24"><div class="grid-content">
              <div>
                  <img src="../assets/images/qingke.png" alt="">
               </div>
              </div></el-col>
            </el-row>
           </el-col>
        </el-row>
        <el-row>
          <el-col :span="16" :push="4">
            <el-row type="flex" justify="space-around">
              <el-col :span="24"><div class="grid-content qingke_footer_word">
              <p>运营机构 : </p>
              <p>氢课（上海）教育科技有限公司</p>
              </div></el-col>

              <el-col :span="24"><div class="grid-content qingke_footer_word">
              <p>售前售后 :</p>
              <p><img src="../assets/images/weiXin.png" alt=""></p>
              <p>GHRVIP13</p>
              <p><img src="../assets/images/weiXin.png" alt=""></p>
              <p>TV@Ghrlib.com</p>
              </div></el-col>

              <el-col :span="24"><div class="grid-content qingke_footer_word">
              <p>市场合作：</p>
              <p><img src="../assets/images/weiXin.png" alt=""></p>
              <p>Marketing@ghrlib.com</p>
              </div></el-col>

              <el-col :span="24"><div class="grid-content qingke_footer_word">
              <p>讲师合作：</p>
              <p><img src="../assets/images/weiXin.png" alt=""></p>
              <p>GHRVIP1</p>
              </div></el-col>
              <el-col :span="24"><div class="grid-content qingke_footer_word">
              <p>热线电话：</p>
              <p><img src="../assets/images/weiXin.png" alt=""></p>
              <p>400-696-2298</p>
              <p></p>
              </div></el-col>
              <el-col :span="24"><div class="grid-content qingke_footer_word">
              <p>官方微信：</p>
              <p><img src="../assets/images/weiXin.png" alt=""></p>
              <p>Qkercom</p>
              <p><img src="../assets/images/weiXin.png" alt=""></p>
              </div></el-col>
            </el-row>
           </el-col>
        </el-row>
        </div>
        -->
    </div>
</template>

<script>
import footerBar from './footer_bar' //导入组件
export default {
    components: {
    	footerBar: footerBar //注册组件
  	},
}
</script>

<style lang="css" scoped>
  .zhuanxing-top{
    font-size: 3rem;
    padding-top: 8%;
    text-align: center;
  }
  .zhuanxing-top>div{
    display: inline-block;
    vertical-align: middle;
  }
  .content{
    text-align: center;
    width:50%;
    margin: 0 auto;
    padding-bottom: 10rem;
    box-shadow: 0.5rem 0.5rem 1rem #f2f2f2;
  }

  .content>p:nth-child(1){
    font-size: 3rem;
  }
  table {
    border-collapse: collapse;
    width:100%;
    margin: 0 auto;
    margin-top: 3%;
    border: 0px solid #999;
  }
  table td {
    border-top: 0;
    border-right: 1px solid #999;
    border-bottom: 1px solid #999;
    border-left: 0;
  }

  .content table{
    border-left:none;
    border-right:none;
    border: none;
  }
  th{
    border: 1px solid #565656;
    border-top:none;
    background-color: #f2f2f2;
    font-size: 2.5rem;
  }
  .left{
    border-left: none;
  }
  .right{
    border-right: none;
  }
  table tr td.lastCol {
    border-right: 0;
    text-align: left;
  }
  .left-center{
    text-align: left;
  }
  .main-head{
    font-size: 1.8rem;
    padding:1rem 2rem;
    width:37%;
  }
  tr,td{
    min-height:6rem;
    font-size: 1.2rem;
    padding:1rem 2rem;
  }
  .qingke_footer{
    background-color: #222222;
    margin-top: 5%;
  }
  .qingke_footer_word>p:nth-child(1){
    font-size: 1.4rem;
    color: #ffffff;
  }
  .qingke_footer_word>p{
    color: #ffffff;
  }
  @media screen and (max-width:640px){
	  .zhuanxing-top{
			padding-top:0;
	  }
    .content{
      width:100%;
      box-sizing:border-box;
	  padding:10px;
    }
    .content table tr{
      padding:0;
    }
    .content table th{
        height:30px;
        line-height:30px;
    }
    .content table td{
     	  padding:0 3px;
    }
    .content table tr td:nth-child(1){
        width:100px;
     }
     .content table tr td:nth-child(2){
        width:10%;
     }
    .main-head{
      width:100%;
     
    }
  }  
</style>
