<template lang="html">
    <div class="contact">
       <div class="contact-white-top">
          <div><img src="../assets/images/green.png" alt=""></div>
          <div>培训业务</div>
       </div>
       <div class="qingke_footer">
          <el-row>
          <el-col :span="16" :push="4">
            <el-row>
              <el-col :span="24"><div class="grid-content">
              <div style="padding-top: 5%">
                  <img src="../assets/images/qingke.png" alt="">
               </div>
              </div></el-col>
            </el-row>
           </el-col>
        </el-row>
        <el-row>
          <el-col :span="16" :push="4">
            <el-row type="flex" justify="space-around">
              <el-col :span="24"><div class="grid-content qingke_footer_word">
              <p>运营机构 : </p>
              <p>氢课（上海）教育科技有限公司</p>
              </div></el-col>

              <el-col :span="24"><div class="grid-content qingke_footer_word">
              <p>售前售后 :</p>
              <p><img src="../assets/images/weiXin.png" alt=""></p>
              <p>GHRVIP13</p>
              <p><img src="../assets/images/weiXin.png" alt=""></p>
              <p>TV@Ghrlib.com</p>
              </div></el-col>

              <el-col :span="24"><div class="grid-content qingke_footer_word">
              <p>市场合作：</p>
              <p><img src="../assets/images/weiXin.png" alt=""></p>
              <p>Marketing@ghrlib.com</p>
              </div></el-col>

              <el-col :span="24"><div class="grid-content qingke_footer_word">
              <p>讲师合作：</p>
              <p><img src="../assets/images/weiXin.png" alt=""></p>
              <p>GHRVIP1</p>
              </div></el-col>
              <el-col :span="24"><div class="grid-content qingke_footer_word">
              <p>热线电话：</p>
              <p><img src="../assets/images/weiXin.png" alt=""></p>
              <p>400-696-2298</p>
              <p></p>
              </div></el-col>
              <el-col :span="24"><div class="grid-content qingke_footer_word">
              <p>官方微信：</p>
              <p><img src="../assets/images/weiXin.png" alt=""></p>
              <p>Qkercom</p>
              <p><img src="../assets/images/weiXin.png" alt=""></p>
              </div></el-col>
            </el-row>
           </el-col>
        </el-row>
        </div>
        <div class="contact-white">
          <div><img src="../assets/images/green.png" alt=""></div>
          <div>微咨询</div>
       </div>
       <div class="qingke_footer">
          <el-row>
          <el-col :span="16" :push="4">
            <el-row>
              <el-col :span="24"><div class="grid-content">
              <div style="padding-top: 5%">
                  <img src="../assets/images/qingke.png" alt="">
               </div>
              </div></el-col>
            </el-row>
           </el-col>
        </el-row>
        <el-row>
          <el-col :span="16" :push="4">
            <el-row type="flex" justify="space-around">
              <el-col :span="24"><div class="grid-content qingke_footer_word">
              <p>运营机构 : </p>
              <p>氢课（上海）教育科技有限公司</p>
              </div></el-col>

              <el-col :span="24"><div class="grid-content qingke_footer_word">
              <p>售前售后 :</p>
              <p><img src="../assets/images/weiXin.png" alt=""></p>
              <p>GHRVIP13</p>
              <p><img src="../assets/images/weiXin.png" alt=""></p>
              <p>TV@Ghrlib.com</p>
              </div></el-col>

              <el-col :span="24"><div class="grid-content qingke_footer_word">
              <p>市场合作：</p>
              <p><img src="../assets/images/weiXin.png" alt=""></p>
              <p>Marketing@ghrlib.com</p>
              </div></el-col>

              <el-col :span="24"><div class="grid-content qingke_footer_word">
              <p>讲师合作：</p>
              <p><img src="../assets/images/weiXin.png" alt=""></p>
              <p>GHRVIP1</p>
              </div></el-col>
              <el-col :span="24"><div class="grid-content qingke_footer_word">
              <p>热线电话：</p>
              <p><img src="../assets/images/weiXin.png" alt=""></p>
              <p>400-696-2298</p>
              <p></p>
              </div></el-col>
              <el-col :span="24"><div class="grid-content qingke_footer_word">
              <p>官方微信：</p>
              <p><img src="../assets/images/weiXin.png" alt=""></p>
              <p>Qkercom</p>
              <p><img src="../assets/images/weiXin.png" alt=""></p>
              </div></el-col>
            </el-row>
           </el-col>
        </el-row>
        </div>
        <div class="contact-white">
          <div><img src="../assets/images/green.png" alt=""></div>
          <div>在线学习</div>
       </div>
       <div class="qingke_footer">
          <el-row>
          <el-col :span="16" :push="4">
            <el-row>
              <el-col :span="24"><div class="grid-content">
              <div style="padding-top: 5%">
                  <img src="../assets/images/qingke.png" alt="">
               </div>
              </div></el-col>
            </el-row>
           </el-col>
        </el-row>
        <el-row>
          <el-col :span="16" :push="4">
            <el-row type="flex" justify="space-around">
              <el-col :span="24"><div class="grid-content qingke_footer_word">
              <p>运营机构 : </p>
              <p>氢课（上海）教育科技有限公司</p>
              </div></el-col>

              <el-col :span="24"><div class="grid-content qingke_footer_word">
              <p>售前售后 :</p>
              <p><img src="../assets/images/weiXin.png" alt=""></p>
              <p>GHRVIP13</p>
              <p><img src="../assets/images/weiXin.png" alt=""></p>
              <p>TV@Ghrlib.com</p>
              </div></el-col>

              <el-col :span="24"><div class="grid-content qingke_footer_word">
              <p>市场合作：</p>
              <p><img src="../assets/images/weiXin.png" alt=""></p>
              <p>Marketing@ghrlib.com</p>
              </div></el-col>

              <el-col :span="24"><div class="grid-content qingke_footer_word">
              <p>讲师合作：</p>
              <p><img src="../assets/images/weiXin.png" alt=""></p>
              <p>GHRVIP1</p>
              </div></el-col>
              <el-col :span="24"><div class="grid-content qingke_footer_word">
              <p>热线电话：</p>
              <p><img src="../assets/images/weiXin.png" alt=""></p>
              <p>400-696-2298</p>
              <p></p>
              </div></el-col>
              <el-col :span="24"><div class="grid-content qingke_footer_word">
              <p>官方微信：</p>
              <p><img src="../assets/images/weiXin.png" alt=""></p>
              <p>Qkercom</p>
              <p><img src="../assets/images/weiXin.png" alt=""></p>
              </div></el-col>
            </el-row>
           </el-col>
        </el-row>
        </div>
        <div class="contact-white">
          <div><img src="../assets/images/green.png" alt=""></div>
          <div>广告合作</div>
       </div>
       <div class="qingke_footer">
          <el-row>
          <el-col :span="16" :push="4">
            <el-row>
              <el-col :span="24"><div class="grid-content">
              <div style="padding-top: 5%">
                  <img src="../assets/images/qingke.png" alt="">
               </div>
              </div></el-col>
            </el-row>
           </el-col>
        </el-row>
        <el-row>
          <el-col :span="16" :push="4">
            <el-row type="flex" justify="space-around">
              <el-col :span="24"><div class="grid-content qingke_footer_word">
              <p>运营机构 : </p>
              <p>氢课（上海）教育科技有限公司</p>
              </div></el-col>

              <el-col :span="24"><div class="grid-content qingke_footer_word">
              <p>售前售后 :</p>
              <p><img src="../assets/images/weiXin.png" alt=""></p>
              <p>GHRVIP13</p>
              <p><img src="../assets/images/weiXin.png" alt=""></p>
              <p>TV@Ghrlib.com</p>
              </div></el-col>

              <el-col :span="24"><div class="grid-content qingke_footer_word">
              <p>市场合作：</p>
              <p><img src="../assets/images/weiXin.png" alt=""></p>
              <p>Marketing@ghrlib.com</p>
              </div></el-col>

              <el-col :span="24"><div class="grid-content qingke_footer_word">
              <p>讲师合作：</p>
              <p><img src="../assets/images/weiXin.png" alt=""></p>
              <p>GHRVIP1</p>
              </div></el-col>
              <el-col :span="24"><div class="grid-content qingke_footer_word">
              <p>热线电话：</p>
              <p><img src="../assets/images/weiXin.png" alt=""></p>
              <p>400-696-2298</p>
              <p></p>
              </div></el-col>
              <el-col :span="24"><div class="grid-content qingke_footer_word">
              <p>官方微信：</p>
              <p><img src="../assets/images/weiXin.png" alt=""></p>
              <p>Qkercom</p>
              <p><img src="../assets/images/weiXin.png" alt=""></p>
              </div></el-col>
            </el-row>
           </el-col>
        </el-row>
        </div>
        <div class="contact-white">
          <div><img src="../assets/images/green.png" alt=""></div>
          <div>市场合作</div>
       </div>
       <div class="qingke_footer">
          <el-row>
          <el-col :span="16" :push="4">
            <el-row>
              <el-col :span="24"><div class="grid-content">
              <div style="padding-top: 5%">
                  <img src="../assets/images/qingke.png" alt="">
               </div>
              </div></el-col>
            </el-row>
           </el-col>
        </el-row>
        <el-row>
          <el-col :span="16" :push="4">
            <el-row type="flex" justify="space-around">
              <el-col :span="24"><div class="grid-content qingke_footer_word">
              <p>运营机构 : </p>
              <p>氢课（上海）教育科技有限公司</p>
              </div></el-col>

              <el-col :span="24"><div class="grid-content qingke_footer_word">
              <p>售前售后 :</p>
              <p><img src="../assets/images/weiXin.png" alt=""></p>
              <p>GHRVIP13</p>
              <p><img src="../assets/images/weiXin.png" alt=""></p>
              <p>TV@Ghrlib.com</p>
              </div></el-col>

              <el-col :span="24"><div class="grid-content qingke_footer_word">
              <p>市场合作：</p>
              <p><img src="../assets/images/weiXin.png" alt=""></p>
              <p>Marketing@ghrlib.com</p>
              </div></el-col>

              <el-col :span="24"><div class="grid-content qingke_footer_word">
              <p>讲师合作：</p>
              <p><img src="../assets/images/weiXin.png" alt=""></p>
              <p>GHRVIP1</p>
              </div></el-col>
              <el-col :span="24"><div class="grid-content qingke_footer_word">
              <p>热线电话：</p>
              <p><img src="../assets/images/weiXin.png" alt=""></p>
              <p>400-696-2298</p>
              <p></p>
              </div></el-col>
              <el-col :span="24"><div class="grid-content qingke_footer_word">
              <p>官方微信：</p>
              <p><img src="../assets/images/weiXin.png" alt=""></p>
              <p>Qkercom</p>
              <p><img src="../assets/images/weiXin.png" alt=""></p>
              </div></el-col>
            </el-row>
           </el-col>
        </el-row>
        </div>
        <div class="contact-white">
          <div><img src="../assets/images/green.png" alt=""></div>
          <div>加入我们</div>
       </div>
       <div class="qingke_footer">
          <el-row>
          <el-col :span="16" :push="4">
            <el-row>
              <el-col :span="24"><div class="grid-content">
              <div style="padding-top: 5%">
                  <img src="../assets/images/qingke.png" alt="">
               </div>
              </div></el-col>
            </el-row>
           </el-col>
        </el-row>
        <el-row>
          <el-col :span="16" :push="4">
            <el-row type="flex" justify="space-around">
              <el-col :span="24"><div class="grid-content qingke_footer_top">
                公司以下职位期待您的加入:
              <p><span></span>产品经理若干</p>
              <p>职位要求 : </p>
              <p>两年从业经验，对工作认真负责。</p>
              </div></el-col>
              <el-col :span="24"><div class="grid-content qingke_footer_top">
              公司以下职位期待您的加入:
              <p><span></span>网页设计师</p>
              <p>职位要求 : </p>
              <p>两年从业经验，对工作认真负责。</p>
              </div></el-col>
              <el-col :span="24"><div class="grid-content qingke_footer_top">
              公司以下职位期待您的加入:
              <p><span></span>平面设计师</p>
              <p>职位要求 : </p>
              <p>两年从业经验，对工作认真负责。</p>
              </div></el-col>
            </el-row>
           </el-col>
        </el-row>
        <el-row>
          <el-col :span="16" :push="4">
            <el-row type="flex" justify="space-around">
              <el-col :span="24"><div class="grid-content qingke_footer_word">
                公司联系方式:
              <p>热线电话 :</p>
              <p><img src="../assets/images/weiXin.png" alt=""></p>
              <p>GHRVIP1</p>
              </div></el-col>
              <el-col :span="24"><div class="grid-content qingke_footer_word">
              <p style="margin-top: 10%">E-Mail :</p>
              <p><img src="../assets/images/weiXin.png" alt=""></p>
              <p>400-696-2298</p>
              <p></p>
              </div></el-col>
              <el-col :span="24"><div class="grid-content qingke_footer_word">
              <p style="margin-top: 10%">HR微信 :</p>
              <p><img src="../assets/images/weiXin.png" alt=""></p>
              <p>Qkercom</p>
              <p><img src="../assets/images/weiXin.png" alt=""></p>
              </div></el-col>
            </el-row>
           </el-col>
        </el-row>
        </div>

    </div>
</template>

<script>
export default {}
</script>

<style lang="css" scoped>
  .contact-white-top{
    background-color: #ffffff;
    text-align: center;
    padding-top: 10%;
    padding-bottom: 5%;
  }
  .contact-white-top>div{
    display: inline-block;
    font-size: 6rem;
    vertical-align: top;
  }
  .contact-white{
    background-color: #ffffff;
    text-align: center;
    padding-top: 5%;
    padding-bottom: 5%;
  }
  .contact-white>div{
    display: inline-block;
    font-size: 6rem;
    vertical-align: top;
  }
  .qingke_footer{
    background-color: #222222;
  }
  .qingke_footer_top{
    color: #ffffff;
    font-size: 1.6rem;
  }
  .qingke_footer_word{
    color: #ffffff;
    font-size: 1.6rem;
  }

  .qingke_footer_word>p:nth-child(1){
    font-size: 1.2rem;
  }
  .qingke_footer_word>p:nth-child(1){
    font-size: 1.4rem;
    color: #ffffff;
    margin-top: 2%;
  }
  .qingke_footer_top>p{
    color: #ffffff;
    font-size: 1.2rem;
    margin-top: 1rem;
  }
  .qingke_footer_top>p>span{
    display: inline-block;
    height:1rem;
    width:1rem;
    margin-right: 1rem;
    background-color: #ffffff;
    border-radius: 50%;
  }
</style>
