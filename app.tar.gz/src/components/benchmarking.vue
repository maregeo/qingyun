<template lang="html">
    <div class="benchmarking">
        <el-row>
          <el-col :span="24"><div class="grid-content bg-purple-dark school_top">
            <!--<xuetangimg src="../assets/images/a1.jpg" alt="" style="width:100%; height: 100vh;">-->
            <p>标杆游学 </p>
            <p>氢云商学连接全国十几万名培训管理者， 云集华为、阿里、腾讯、百度、GE、IBM 等众多国内外知名标杆企业，以“行业对标， 量身定制”为特色，根据企业不同发展阶段 和实际需求，制订符合其发展要求的内训与 咨询方案。服务形式包括内训、微咨询、入 企咨询辅导、常年顾问服务四大类。</p>
          </div></el-col>
        </el-row>
        <div class="content">
          <p class="content-top">产品目录</p>
          <table>
            <tr>
              <th>Firstname</th>
              <th>Lastname</th>
              <th>Firstname</th>
              <th>Lastname</th>
              <th>Firstname</th>
              <th>Lastname</th>
            </tr>
            <tr>
              <td>1</td>
              <td><a href=""><img src="../assets/images/HW.png" alt=""></a></td>
              <td>管理创新</td>
              <td>Griffin</td>
              <td>Peter</td>
              <td>Griffin</td>
            </tr>
            <tr>
              <td>2</td>
              <td><a href=""><img src="../assets/images/AL.png" alt=""></a></td>
              <td>Lois</td>
              <td>Griffin</td>
              <td>Lois</td>
              <td>Griffin</td>
            </tr>
            <tr>
              <td>3</td>
              <td><a href=""><img src="../assets/images/TX.png" alt=""></a></td>
              <td>Lois</td>
              <td>Griffin</td>
              <td>Lois</td>
              <td>Griffin</td>
            </tr>
            <tr>
              <td>4</td>
               <td><a href=""><img src="../assets/images/TECSON.png" alt=""></a></td>
              <td>Lois</td>
              <td>Griffin</td>
              <td>Lois</td>
              <td>Griffin</td>
            </tr>
            <tr>
              <td>5</td>
              <td><a href=""><img src="../assets/images/HAIER.png" alt=""></a></td>
              <td>Lois</td>
              <td>Griffin</td>
              <td>Lois</td>
              <td>Griffin</td>
            </tr>
            <tr>
              <td>6</td>
              <td><a href=""><img src="../assets/images/XM.png" alt=""></a></td>
              <td>Loisdru7</td>
              <td>Griffin</td>
              <td>Lois</td>
              <td>Griffiwdqn</td>
            </tr>
            <tr>
              <td>7</td>
              <td><img src="../assets/images/JD.png" alt=""></td>
              <td>Loisdru7</td>
              <td>Griffin</td>
              <td>Lois</td>
              <td>Griffiwdqn</td>
            </tr>
            <tr>
              <td>8</td>
              <td><img src="../assets/images/MT.png" alt=""></td>
              <td>Loisdru7</td>
              <td>Griffin</td>
              <td>Lois</td>
              <td>Griffiwdqn</td>
            </tr>
            <tr>
              <td>9</td>
              <td><img src="../assets/images/RCOLLAR.png" alt=""></td>
              <td>Loisdru7</td>
              <td>Griffin</td>
              <td>Lois</td>
              <td>Griffiwdqn</td>
            </tr>
            <tr>
              <td>10</td>
              <td><img src="../assets/images/KG.png" alt=""></td>
              <td>Loisdru7</td>
              <td>Griffin</td>
              <td>Lois</td>
              <td>Griffiwdqn</td>
            </tr>
            <tr>
              <td>11</td>
              <td><img src="../assets/images/MARK.png" alt=""></td>
              <td>Loisdru7</td>
              <td>Griffin</td>
              <td>Lois</td>
              <td>Griffiwdqn</td>
            </tr>
            <tr>
              <td>12</td>
              <td><img src="../assets/images/FOTILE.png" alt=""></td>
              <td>Loisdru7</td>
              <td>Griffin</td>
              <td>Lois</td>
              <td>Griffiwdqn</td>
            </tr>
            <tr>
              <td>13</td>
              <td><img src="../assets/images/TS.png" alt=""></td>
              <td>Loisdru7</td>
              <td>Griffin</td>
              <td>Lois</td>
              <td>Griffiwdqn</td>
            </tr>
            <tr>
              <td>14</td>
              <td><img src="../assets/images/TOYOTA.png" alt=""></td>
              <td>Loisdru7</td>
              <td>Griffin</td>
              <td>Lois</td>
              <td>Griffiwdqn</td>
            </tr>
            <tr>
              <td>15</td>
              <td><img src="../assets/images/YYK.png" alt=""></td>
              <td>Loisdru7</td>
              <td>Griffin</td>
              <td>Lois</td>
              <td>Griffiwdqn</td>
            </tr>
          </table>
          <div style="text-align: left;margin-left: 26%" class="content-bottom-top">*备注：</div>
           <div style="text-align: left;margin-left: 26%" class="content-bottom-bottom">以上主题全部包括实地考察参观；游学主题和主讲人，可根据客户实际需求定制，以上仅供参考。</div>
        </div>
        <div class="qingke_footer">
          <el-row>
          <el-col :span="16" :push="4">
            <el-row>
              <el-col :span="24"><div class="grid-content">
              <div>
                  <img src="../assets/images/logo.png" alt="" style="height: 5rem;width:rem;padding-top: 2rem">
               </div>
              </div></el-col>
            </el-row>
           </el-col>
        </el-row>
        <el-row>
          <el-col :span="16" :push="4">
            <el-row type="flex" justify="space-around">
              <el-col :span="24"><div class="grid-content qingke_footer_word">
              <p>
              <span><img src="" alt=""></span>
              <span class="convention_bottom">175 66666 666</span>
              </p>
              <p>
              <span><img src="" alt=""></span>
              <span class="convention_bottom">上海市 长宁区</span>
              </p>
              <p>
              <span><img src="" alt=""></span>
              <span class="convention_bottom">GHRLIB@XX.COM</span>
              </p>
              </div></el-col>

              <el-col :span="24"><div class="grid-content qingke_footer_word">
              <p>旗下品牌：</p>
              <p>
                <span><img src="../assets/images/weiXin.png" alt="" style="height: 2rem;width:3rem;"></span>
                <span><img src="../assets/images/weiXin.png" alt="" style="height: 2rem;width:3rem;"></span>
              </p>
              <p>
                <span><img src="../assets/images/weiXin.png" alt="" style="height: 2rem;width:3rem;"></span>
                <span><img src="../assets/images/weiXin.png" alt="" style="height: 2rem;width:3rem;"></span>
              </p>
              <p>
                <span><img src="../assets/images/weiXin.png" alt="" style="height: 2rem;width:3rem;"></span>
                <span><img src="../assets/images/weiXin.png" alt="" style="height: 2rem;width:3rem;"></span>
              </p>
              </div></el-col>

              <el-col :span="24"><div class="grid-content qingke_footer_word">
              <p>在线学习：</p>
              <p><img src="../assets/images/weiXin.png" alt=""></p>
              <p><img src="../assets/images/weiXin.png" alt=""></p>
              <p><img src="../assets/images/weiXin.png" alt=""></p>
              </div></el-col>
              <el-col :span="24"><div class="grid-content qingke_footer_word constant">
              <p>联系电话：</p>
              <p>培训业务</p>
              <p>微咨询</p>
              <p>在线学习</p>
              <p>广告合作</p>
              <p>市场合作</p>
              <p>加入我们</p>
              </div></el-col>
              <el-col :span="24"><div class="grid-content qingke_footer_word">
              <p>市场合作：</p>
              <p>市场合作：</p>
              </div></el-col>
            </el-row>
           </el-col>
        </el-row>
        </div>
    </div>
</template>

<script>
export default {}
</script>

<style lang="css" scoped>
  .school_top{
    height:100vh;
    width:100%;
    background-image: url("../assets/images/ask.jpg");
    background-size: 100% 100%;
  }
  .school_top>p:nth-child(1){
    font-size: 6rem;
    color: #ffbc08;
    position: absolute;
    top:35%;
    left: 30%;
  }
  .school_top>p:nth-child(2){
    font-size: 2rem;
    width:25%;
    position: absolute;
    color: #ffffff;
    top:45%;
    left: 30%;
  }
  .school_top>p:nth-child(3){
    color: #ffffff;
    font-size: 3rem;
    position: absolute;
    top:70%;
    left: 30%;
    left: 30%;
    vertical-align: top;
  }
  .content{
    text-align: center;
  }
  .content>p:nth-child(1){
    font-size: 3rem;
  }
  table {
    border-collapse: collapse;
    width:50%;
    margin: 0 auto;
    margin-top: 3%;
  }

  table, td, th {
    border: 1px solid black;
  }
th{
  background-color: #f2f2f2;
}
  tr,td{
    height:4rem;
  }
  .content-bottom-top{
    font-size: 1.6rem;
    font-weight: 600;
  }
  .content-bottom-bottom{
    font-size: 1.4rem;
    margin-bottom: 5%;
  }
  .qingke_footer{
    background-color: #222222;
    padding-top: 2%;
  }
  .qingke_footer_word>p:nth-child(1){
    font-size: 1.4rem;
    color: #ffffff;
  }
  .qingke_footer_word>p{
    color: #ffffff;
  }
</style>
