<!--<template lang="html">-->
    <!--<div class="test">-->
        <!--<el-row>-->
          <!--<el-col :span="24"><div class="grid-content bg-purple-dark" >-->
            <!--<div class="sy_car_third" >-->
              <!--<p style="margin-bottom: 2%">成功案例</p>-->
              <!--<p style="margin-bottom: 0">氢云新媒体矩阵包括环球人力资源智库、解读标杆、每天学点HR、 管理定见等优质微信公众号，各具特色，功能互补，错位发展。 我们坚持重视新媒体、用好新媒体，发挥新媒体力量， 为广大读者和提供更专业、更有效、更有力的传播服务， 海量信息和深度资讯充分融通，打造优质新媒体联合传播平台。 你我在这里交汇。150W+关注，10W+量产，多元聚焦、深度广泛， 专注分享推送优质内容和产品，多篇原创深度研究文章引发刷屏风潮， 花式给你好看。</p>-->
            <!--</div>-->
          <!--</div></el-col>-->
        <!--</el-row>-->
        <!--<el-row>-->
          <!--<el-col :span="14" :push="5">-->
            <!--<el-row>-->
              <!--<el-col :span="4" :xs="24"><div class="grid-content card">-->
                <!--<div class="card-card">-->

                <!--</div>-->
              <!--</div></el-col>-->
              <!--<el-col :span="4" :xs="24"><div class="grid-content card">-->
                <!--<div class="card-card">-->
                <!--</div>-->
              <!--</div></el-col>-->
              <!--<el-col :span="8" :xs="24"><div class="grid-content card">-->
                <!--<div class="card-content">-->
                <!--</div>-->
              <!--</div></el-col>-->
              <!--<el-col :span="4" :xs="24"><div class="grid-content card">-->
                <!--<div class="card-card">-->
                <!--</div>-->
              <!--</div></el-col>-->
              <!--<el-col :span="4" :xs="24"><div class="grid-content card">-->
                <!--<div class="card-card">-->
                <!--</div>-->
              <!--</div></el-col>-->
            <!--</el-row>-->
            <!--<el-row>-->
              <!--<el-col :span="12"><div class="grid-content">-->
                <!--<div class="left">-->
                  <!--<div class="pic"></div>-->
                  <!--<div class="word">-->
                    <!--<div class="title">环球人力资源智库(GHR)</div>-->
                    <!--<div class="click-more">点击了解更多</div>-->
                  <!--</div>-->
                <!--</div>-->
              <!--</div></el-col>-->
              <!--<el-col :span="12"><div class="grid-content">-->
                <!--<div class="right">-->
                  <!--<div class="word">-->
                    <!--<div class="title">每天学点HR</div>-->
                    <!--<div class="click-more" >点击了解更多</div>-->
                  <!--</div>-->
                  <!--<div class="pic"></div>-->
                <!--</div>-->
              <!--</div></el-col>-->
              <!--<el-col :span="24"><div class="grid-content">-->
                <!--<div class="center">astrkuif</div>-->
              <!--</div></el-col>-->
              <!--<el-col :span="12"><div class="grid-content">-->
                <!--<div class="left">-->
                  <!--<div class="pic"></div>-->
                  <!--<div class="word">-->
                    <!--<div class="title">环球人力资源智库(GHR)</div>-->
                    <!--<div class="click-more">点击了解更多</div>-->
                  <!--</div>-->
                <!--</div>-->
              <!--</div></el-col>-->
              <!--<el-col :span="12"><div class="grid-content">-->
                <!--<div class="right">-->
                  <!--<div class="word">-->
                    <!--<div class="title">每天学点HR</div>-->
                    <!--<div class="click-more" >点击了解更多</div>-->
                  <!--</div>-->
                  <!--<div class="pic"></div>-->
                <!--</div>-->
              <!--</div></el-col>-->
            <!--</el-row>-->
          <!--</el-col>-->
        <!--</el-row>-->
    <!--</div>-->
<!--</template>-->

<!--<script>-->
<!--export default {}-->
<!--</script>-->

<!--<style lang="css">-->
  <!--.card{-->
    <!--margin: 0 auto;-->
    <!--margin-top: 3%;-->
    <!--vertical-align: bottom;-->
  <!--}-->
  <!--.card-card{-->
    <!--width: 12rem;-->
    <!--height:20rem;-->
    <!--margin: 0 auto;-->
    <!--background-color: #d3dce6;-->
  <!--}-->
  <!--.card-content{-->
    <!--height:20rem;-->
    <!--width:20rem;-->
    <!--margin: 0 auto;-->
    <!--background-color: #d3dce6;-->
  <!--}-->
  <!--.left{-->
    <!--display: flex;-->
    <!--justify-content: flex-start;-->
  <!--}-->
  <!--.right{-->
    <!--margin-right: 0;-->
    <!--display: flex;-->
    <!--justify-content: flex-end;-->
  <!--}-->
  <!--.pic{-->
    <!--height:12rem;-->
    <!--width:12rem;-->
    <!--background-color: #d3dce6;-->
  <!--}-->
  <!--.title{-->
    <!--font-size: 1.6rem;-->
    <!--font-weight: 600;-->
  <!--}-->
  <!--.click-more{-->
    <!--font-size: 1.2rem;-->
    <!--width:10rem;-->
    <!--color: #ffffff;-->
    <!--background-color: #565656;-->
  <!--}-->
  <!--.word{-->
    <!--text-align: center;-->
    <!--margin: auto 2%;-->
  <!--}-->
  <!--.center{-->
    <!--width:100%;-->
    <!--margin: 0 auto;-->
  <!--}-->
  <!--.grid-content{-->
    <!--text-align: center;-->
    <!--font-size: 20rem;-->
  <!--}-->
<!--</style>-->
<template lang="html">
    <div class="media">
      <div class="sy_car_third">
        <p>近期课程</p>
        <p>环球人力资源智库（GHR/GHRlib）—— 最具影响力人力资源新媒体， 最好的HR学习地盘；组织学习与人才培养专家，致力于推动中国企业 人力资源效能提升与组织转型。</p>
        <el-row>
          <el-col :span="10" :push="6">
            <el-row>
              <el-col :span="24">
              <div class="grid-content bg-purple-light">
                <img src="../assets/images/qy-media.png" alt="" style="width: 100%;">
              </div>
            </el-col>
              <!--<el-col :span="4">-->
                <!--<div class="grid-content" style="margin: 0 auto">-->
                  <!--<img src="../assets/images/red_logo.png" alt="" class="img">-->
                <!--</div>-->
              <!--</el-col>-->
              <!--<el-col :span="8">-->
                <!--<div class="grid-content" style="margin: 0 auto">-->
                  <!--<img src="../assets/images/red_logo.png" alt="" style="height: 15rem" class="img">-->
                <!--</div>-->
              <!--</el-col>-->
              <!--<el-col :span="4">-->
                <!--<div class="grid-content" style="margin: 0 auto">-->
                  <!--<img src="../assets/images/red_logo.png" alt="" class="img">-->
                <!--</div>-->
              <!--</el-col>-->
              <!--<el-col :span="4">-->
                <!--<div class="grid-content" style="margin: 0 auto">-->
                  <!--<img src="../assets/images/red_logo.png" alt="" class="img">-->
                <!--</div>-->
              <!--</el-col>-->
              <el-row>
              <el-col :span="12"><div class="grid-content" style="margin-top: 2rem">
                <div class="left">
                  <div class="pic"><img src="../assets/images/red_logo.png" alt="" style="width: 100%;"></div>
                  <div class="word">
                    <div class="title">环球人力资源智库(GHR)</div>
                       <div class="click-more" ><el-button type="text" @click="centerDialogVisible = true">点击了解更多</el-button>

                    <el-dialog
                      title=""
                      :visible.sync="centerDialogVisible"
                      fullscreen="true"
                      center>
                      <span style="display:inline-block;margin-top: 8%" >
                        <el-row>
                          <el-col :span="8" :push="8"  class="v-alert-main">
                            <el-row >
                              <el-col :span="24" ><div class="grid-content">
                                <img src="../assets/images/sleep.png" alt="" class="sleep">
                                <div class="sleep-word">睡前学管理</div>
                                <div class="word-min">氢云新媒体矩阵包括环球人力资源智库、解读标杆、每天学点HR、 管理定见等优质微信公众号，各具特色，功能互补，错位发展。 我们坚持重视新媒体、用好新媒体，发挥新媒体力量， 为广大读者和提供更专业、更有效、更有力的传播服务， 海量信息和深度资讯充分融通，打造优质新媒体联合传播平台。</div>
                                <div class="sleep-footer">
                                  <div class="sleep-left"><img src="../assets/images/manage_sign.jpg" alt=""></div>
                                  <div class="sleep-right">
                                    <p>扫描识别二维码</p>
                                    <p>关注睡前学管理</p>
                                    <img src="../assets/images/weiXin.png" alt="">
                                   </div>
                                </div>
                              </div></el-col>
                            </el-row>
                          </el-col>
                        </el-row>
                      </span>
                    </el-dialog></div>
                  </div>
                </div>
              </div></el-col>
              <el-col :span="12" style="margin-top: 2rem"><div class="grid-content">
                <div class="right">
                  <div class="word">
                    <div class="title">每天学点HR</div>
                    <div class="click-more" ><el-button type="text" @click="centerDialogVisible = true">点击了解更多</el-button>

                    <el-dialog
                      title=""
                      :visible.sync="centerDialogVisible"
                      fullscreen="true"
                      center>
                      <span style="display:inline-block;margin-top: 8%">
                        <el-row>
                          <el-col :span="8" :push="8"  class="v-alert-main">
                            <el-row >
                              <el-col :span="24" ><div class="grid-content">
                                <img src="../assets/images/sleep.png" alt="" class="sleep">
                                <div class="sleep-word">睡前学管理</div>
                                <div class="word-min">氢云新媒体矩阵包括环球人力资源智库、解读标杆、每天学点HR、 管理定见等优质微信公众号，各具特色，功能互补，错位发展。 我们坚持重视新媒体、用好新媒体，发挥新媒体力量， 为广大读者和提供更专业、更有效、更有力的传播服务， 海量信息和深度资讯充分融通，打造优质新媒体联合传播平台。</div>
                                <div class="sleep-footer">
                                  <div class="sleep-left"><img src="../assets/images/manage_sign.jpg" alt=""></div>
                                  <div class="sleep-right">
                                    <p>扫描识别二维码</p>
                                    <p>关注睡前学管理</p>
                                    <img src="../assets/images/weiXin.png" alt="">
                                   </div>
                                </div>
                              </div></el-col>
                            </el-row>
                          </el-col>
                        </el-row>
                      </span>
                    </el-dialog></div>
                  </div>
                  <div class="pic"><img src="../assets/images/study.png" alt="" style="width: 100%"></div>
                </div>
              </div></el-col>
              <el-col :span="24"><div class="grid-content" style="text-align: center">
                <div class="center" style="height:15rem;width: 12rem;margin: 0 auto"><img src="../assets/images/hand.png" alt=""style="width: 100%"></div>
              </div></el-col>
              <el-col :span="12"><div class="grid-content">
                <div class="left">
                  <div class="pic"><img src="../assets/images/manage.png" alt="" style="width: 100%"></div>
                  <div class="word">
                    <div class="title">环球人力资源智库(GHR)</div>
                       <div class="click-more" ><el-button type="text" @click="centerDialogVisible = true">点击了解更多</el-button>

                    <el-dialog
                      title=""
                      :visible.sync="centerDialogVisible"
                      fullscreen="true"
                      center>
                      <span style="display:inline-block;margin-top: 8%" >
                        <el-row>
                          <el-col :span="8" :push="8" class="v-alert-main">
                            <el-row >
                              <el-col :span="24" ><div class="grid-content">
                                <img src="../assets/images/sleep.png" alt="" class="sleep">
                                <div class="sleep-word">睡前学管理</div>
                                <div class="word-min">氢云新媒体矩阵包括环球人力资源智库、解读标杆、每天学点HR、 管理定见等优质微信公众号，各具特色，功能互补，错位发展。 我们坚持重视新媒体、用好新媒体，发挥新媒体力量， 为广大读者和提供更专业、更有效、更有力的传播服务， 海量信息和深度资讯充分融通，打造优质新媒体联合传播平台。</div>
                                <div class="sleep-footer">
                                  <div class="sleep-left"><img src="../assets/images/manage_sign.jpg" alt=""></div>
                                  <div class="sleep-right">
                                    <p>扫描识别二维码</p>
                                    <p>关注睡前学管理</p>
                                    <img src="../assets/images/weiXin.png" alt="">
                                   </div>
                                </div>
                              </div></el-col>
                            </el-row>
                          </el-col>
                        </el-row>
                      </span>
                    </el-dialog></div>
                  </div>
                </div>
              </div></el-col>
              <el-col :span="12"><div class="grid-content">
                <div class="right">
                  <div class="word">
                    <div class="title">每天学点HR</div>
                       <div class="click-more" ><el-button type="text" @click="centerDialogVisible = true">点击了解更多</el-button>

                    <el-dialog
                      title=""
                      :visible.sync="centerDialogVisible"
                      fullscreen="true"
                      center>
                      <span style="display:inline-block;margin-top: 8%">
                        <el-row>
                          <el-col :span="8" :push="8" class="v-alert-main">
                            <el-row >
                              <el-col :span="24" ><div class="grid-content">
                                <img src="../assets/images/sleep.png" alt="" class="sleep">
                                <div class="sleep-word">睡前学管理</div>
                                <div class="word-min">氢云新媒体矩阵包括环球人力资源智库、解读标杆、每天学点HR、 管理定见等优质微信公众号，各具特色，功能互补，错位发展。 我们坚持重视新媒体、用好新媒体，发挥新媒体力量， 为广大读者和提供更专业、更有效、更有力的传播服务， 海量信息和深度资讯充分融通，打造优质新媒体联合传播平台。</div>
                                <div class="sleep-footer">
                                  <div class="sleep-left"><img src="../assets/images/manage_sign.jpg" alt=""></div>
                                  <div class="sleep-right">
                                    <p>扫描识别二维码</p>
                                    <p>关注睡前学管理</p>
                                    <img src="../assets/images/weiXin.png" alt="">
                                   </div>
                                </div>
                              </div></el-col>
                            </el-row>
                          </el-col>
                        </el-row>
                      </span>
                    </el-dialog></div>
                  </div>
                  <div class="pic"><img src="../assets/images/read.png" alt="" style="width:100% ;"></div>
                </div>
              </div></el-col>
            </el-row>
            </el-row>
          </el-col>
        </el-row>
      </div>
      <div class="sy_car_second">
        <p style="margin-bottom: 2%">特约撰稿人</p>
        <p style="margin-bottom: 2%">氢云新媒体矩阵包括环球人力资源智库、解读标杆、 每天学点HR、管理定见等优质微信公众号， 各具特色，功能互补，错位发展。</p>
        <el-row>
          <el-col :span="12" :push="6" style="padding-bottom: 5rem">
            <el-row :gutter="20">
              <el-col :span="12" :xs="24" :ms="24">
                <div class="grid-content ">
                  <div class="name_list">
                    <div class="card-left" style="height:11rem;width:11rem;" @click="jumpDetail"></div>
                    <div class="card-right">
                      <div class="card-right-top">穆胜</div>
                      <div class="card-right-bottom">
                        <ul>
                          <li>环球人力资源智库 专家委员会执行主席</li>
                          <li>北京大学光华管理学院工商管理博士后</li>
                          <li>胜宴私董会创始人、总裁教练</li>
                          <li>中兴通讯、华夏航空等知名企业常年管理顾问 </li>
                          <li>海尔研究院商业模式转型领衔专家</li>
                        </ul>
                      </div>
                    </div>
                  </div>
                </div>
              </el-col>
              <el-col :span="12" :xs="24">
                <div class="grid-content ">
                  <div class="name_list">
                    <div class="card-left" style="height:11rem;width:11rem;" @click="jumpDetail"></div>
                    <div class="card-right">
                      <div class="card-right-top">穆胜</div>
                      <div class="card-right-bottom">
                        <ul>
                          <li>环球人力资源智库 专家委员会执行主席</li>
                          <li>北京大学光华管理学院工商管理博士后</li>
                          <li>胜宴私董会创始人、总裁教练</li>
                          <li>中兴通讯、华夏航空等知名企业常年管理顾问 </li>
                          <li>海尔研究院商业模式转型领衔专家</li>
                        </ul>
                      </div>
                    </div>
                    </div>
                </div>
              </el-col>
              <el-col :span="12" :xs="24">
                <div class="grid-content ">
                  <div class="name_list">
                    <div class="card-left" style="height:11rem;width:11rem;" @click="jumpDetail"></div>
                    <div class="card-right">
                      <div class="card-right-top">穆胜</div>
                      <div class="card-right-bottom">
                        <ul>
                          <li>环球人力资源智库 专家委员会执行主席</li>
                          <li>北京大学光华管理学院工商管理博士后</li>
                          <li>胜宴私董会创始人、总裁教练</li>
                          <li>中兴通讯、华夏航空等知名企业常年管理顾问 </li>
                          <li>海尔研究院商业模式转型领衔专家</li>
                        </ul>
                      </div>
                    </div>
                    </div>
                </div>
              </el-col>
              <el-col :span="12" :xs="24">
                <div class="grid-content ">
                  <div class="name_list">
                    <div class="card-left" style="height:11rem;width:11rem;" @click="jumpDetail"></div>
                    <div class="card-right">
                      <div class="card-right-top">穆胜</div>
                      <div class="card-right-bottom">
                        <ul>
                          <li>环球人力资源智库 专家委员会执行主席</li>
                          <li>北京大学光华管理学院工商管理博士后</li>
                          <li>胜宴私董会创始人、总裁教练</li>
                          <li>中兴通讯、华夏航空等知名企业常年管理顾问 </li>
                          <li>海尔研究院商业模式转型领衔专家</li>
                        </ul>
                      </div>
                    </div>
                    </div>
                </div>
              </el-col>
              <el-col :span="12" :xs="24">
                <div class="grid-content ">
                  <div class="name_list">
                    <div class="card-left" style="height:11rem;width:11rem;" @click="jumpDetail"></div>
                    <div class="card-right">
                      <div class="card-right-top">穆胜</div>
                      <div class="card-right-bottom">
                        <ul>
                          <li>环球人力资源智库 专家委员会执行主席</li>
                          <li>北京大学光华管理学院工商管理博士后</li>
                          <li>胜宴私董会创始人、总裁教练</li>
                          <li>中兴通讯、华夏航空等知名企业常年管理顾问 </li>
                          <li>海尔研究院商业模式转型领衔专家</li>
                        </ul>
                      </div>
                    </div>
                    </div>
                </div>
              </el-col>
              <el-col :span="12" :xs="24">
                <div class="grid-content ">
                 <div class="name_list">
                    <div class="card-left" style="height:11rem;width:11rem;" @click="jumpDetail"></div>
                    <div class="card-right">
                      <div class="card-right-top">穆胜</div>
                      <div class="card-right-bottom">
                        <ul>
                          <li>环球人力资源智库 专家委员会执行主席</li>
                          <li>北京大学光华管理学院工商管理博士后</li>
                          <li>胜宴私董会创始人、总裁教练</li>
                          <li>中兴通讯、华夏航空等知名企业常年管理顾问 </li>
                          <li>海尔研究院商业模式转型领衔专家</li>
                        </ul>
                      </div>
                    </div>
                    </div>
                </div>
              </el-col>
            </el-row>
          </el-col>
        </el-row>
      </div>
      <div class="sy_car_third" style="margin-top: -5%">
        <p style="margin: 2%;padding-top: 0">广告合作 </p>
        <p style="margin-bottom: 2%">氢云新媒体矩阵包括环球人力资源智库、解读标杆、 每天学点HR、管理定见等优质微信公众号， 各具特色，功能互补，错位发展。</p>
        <el-row>
          <el-col :span="12" :push="6">
            <el-row :gutter="20">
              <el-col :span="24">
                    <table>
                      <tr>
                        <th>时间</th>
                        <th>分享主题</th>
                        <th>分享嘉宾</th>
                        <th>时间</th>
                        <th>分享主题</th>
                        <th>分享嘉宾</th>
                      </tr>
                      <tr>
                        <td>环球人力资源智库</td>
                        <td>Griffin</td>
                        <td>desgf</td>
                        <td>环球人力资源智库</td>
                        <td>Griffin</td>
                        <td>desgf</td>
                      </tr>
                      <tr>
                        <td>Lois</td>
                        <td>Griffin</td>
                        <td>desgf</td>
                        <td>环球人力资源智库</td>
                        <td>Griffin</td>
                        <td>desgf</td>
                      </tr>
                      <tr>
                        <td>Lois</td>
                        <td>Griffin</td>
                        <td>sdfgtr</td>
                        <td>环球人力资源智库</td>
                        <td>Griffin</td>
                        <td>desgf</td>
                      </tr>
                      <tr>
                        <td>Lois</td>
                        <td>Griffin</td>
                        <td>sdfgtr</td>
                        <td>环球人力资源智库</td>
                        <td>Griffin</td>
                        <td>desgf</td>
                      </tr>
                    </table>
                      <p style="font-size: 1.6rem;text-align: left">备注：</p>
                      <p style="font-size: 1.2rem;text-align: left">1.氢云新媒体矩阵包括环球人力资源智库、解读标杆、每天学点HR、管理定见等优质微信公众号，各具特色，功能互补，错位发展。</p>
                      <p style="font-size: 1.2rem;text-align: left">1.氢云新媒体矩阵包括环球人力资源智库、解读标杆、每天学点HR、管理定见等优质微信公众号，各具特色，功能互补，错位发展。</p>
                      <p style="font-size: 1.2rem;text-align: left">1.氢云新媒体矩阵包括环球人力资源智库、解读标杆、每天学点HR、管理定见等优质微信公众号，各具特色，功能互补，错位发展。</p>
              </el-col>
            </el-row>
            <el-col :span="24">
            <div class="grid-content"style="margin-top: -5%">
              <div class="btn_more" @click="jumpcontact">点击此处进入合作</div>
            </div>
          </el-col>
          </el-col>
        </el-row>
      </div>
      <div class="sy_car_third">
        <p>百万HR的 共同选择 </p>
        <p>环球人力资源智库（GHR/GHRlib）—— 最具影响力人力资源新媒体， 最好的HR学习地盘；组织学习与人才培养专家，致力于推动中国企业 人力资源效能提升与组织转型。</p>
        <el-row>
          <el-col :span="12" :push="6">
            <el-row :gutter="20">
              <el-col :span="6" :xs="12" :ms="14" :md="12" :lg="6" v-for="item in logos" key="logos">
                <div class="parent">
                  <div class="list_icon">
                    <div><img :src="getImg(item)" alt="" style="width: 13rem;"></div>
                  </div>
                </div>
              </el-col>
            </el-row>
          </el-col>
        </el-row>
      </div>
            <div class="qingke_footer">
          <el-row>
          <el-col :span="16" :push="4">
            <el-row>
              <el-col :span="24"><div class="grid-content">
              <div>
                  <img src="../assets/images/logo.png" alt="" style="height: 5rem;width:rem;padding-top: 2rem">
               </div>
              </div></el-col>
            </el-row>
           </el-col>
        </el-row>
        <el-row>
          <el-col :span="16" :push="4">
            <el-row type="flex" justify="space-around">
              <el-col :span="24"><div class="grid-content qingke_footer_word">
              <p>
              <span><img src="" alt=""></span>
              <span class="convention_bottom">175 66666 666</span>
              </p>
              <p>
              <span><img src="" alt=""></span>
              <span class="convention_bottom">上海市 长宁区</span>
              </p>
              <p>
              <span><img src="" alt=""></span>
              <span class="convention_bottom">GHRLIB@XX.COM</span>
              </p>
              </div></el-col>

              <el-col :span="24"><div class="grid-content qingke_footer_word">
              <p>旗下品牌：</p>
              <p>
                <span><img src="../assets/images/weiXin.png" alt="" style="height: 2rem;width:3rem;"></span>
                <span><img src="../assets/images/weiXin.png" alt="" style="height: 2rem;width:3rem;"></span>
              </p>
              <p>
                <span><img src="../assets/images/weiXin.png" alt="" style="height: 2rem;width:3rem;"></span>
                <span><img src="../assets/images/weiXin.png" alt="" style="height: 2rem;width:3rem;"></span>
              </p>
              <p>
                <span><img src="../assets/images/weiXin.png" alt="" style="height: 2rem;width:3rem;"></span>
                <span><img src="../assets/images/weiXin.png" alt="" style="height: 2rem;width:3rem;"></span>
              </p>
              </div></el-col>

              <el-col :span="24"><div class="grid-content qingke_footer_word">
              <p>在线学习：</p>
              <p><img src="../assets/images/weiXin.png" alt=""></p>
              <p><img src="../assets/images/weiXin.png" alt=""></p>
              <p><img src="../assets/images/weiXin.png" alt=""></p>
              </div></el-col>
              <el-col :span="24"><div class="grid-content qingke_footer_word constant">
              <p>联系电话：</p>
              <p>培训业务</p>
              <p>微咨询</p>
              <p>在线学习</p>
              <p>广告合作</p>
              <p>市场合作</p>
              <p>加入我们</p>
              </div></el-col>
              <el-col :span="24"><div class="grid-content qingke_footer_word">
              <p>市场合作：</p>
              <p>市场合作：</p>
              </div></el-col>
            </el-row>
           </el-col>
        </el-row>
        </div>
    </div>
</template>

<script>
  export default {
    name: 'startReport',
    data (){
      return{
        centerDialogVisible: false,
        logos: [
          'ali.png',
          'tencent.png',
          'qs.png',
          'bayer-01.png',
          'flp.png',
          'ft.png',
          'parker-01.png',
          'liNing.png',
          'nh.png',
          'lianTong.png',
          'meiDi.png',
          'jh.png',
          'sq.png',
          'wangYi.png'
        ]
      }
    },
    methods:{
      jumpcontact(){
        this.$router.push('/contact')
      },
      jumpDetail(){
        this.$router.push('/detail')
      },
      getImg(url) {
        // console.log(url)'../assets/images/'+
        return require(`../assets/images/${url}`)
      }
    }
  }
</script>

<style lang="css" scoped>
  .sy_car_third>p:nth-child(1){
    padding-top: 5rem;
  }
  .img{
    height:12rem;
    width:12rem;
  }
  .left{
    display: flex;
    justify-content: flex-start;
  }
  .right{
    margin-right: 0;
    display: flex;
    justify-content: flex-end;
  }
  .pic{
    height:12rem;
    width:12rem;
    background-color: #d3dce6;
  }
  .title{
    font-size: 1.6rem;
    font-weight: 600;
  }
  .click-more .el-button{
    font-size: 1.2rem;
    width:10rem;
    padding:0.35rem;
    color: #ffffff;
    background-color: #565656;
  }
  .word{
    text-align: center;
    margin: auto 2%;
  }
  .name_list{
    display: flex;
    color: #FCD281;
    justify-content: space-between;
    margin-top:2rem;
  }
  .card-left{
    height:5rem;
    width:5rem;
    background-color: #FCD281;
    border-radius: 50%;
  }
  .card-left{
    color: #FCD281;
  }
  .card-right{
    width:60%;
    text-align: left;
  }
  .card-right-top{
    font-size: 2rem;
  }
  .card-right-bottom{
    border: 0.2rem solid #ffffff;
  }
  .card-right-bottom>ul{
    width:80%;
    padding:0 0 0.2rem 2rem;
  }
  .card-right-bottom>ul>li{
    margin-top: 0.2rem;
    font-size: 0.8rem;
  }
  table {
    width:100%;
    border-collapse: collapse;
    box-shadow: 1rem 1rem 0.5rem #f2f2f2;
    border-bottom: none;
  }
  table,th, td
  {
    border: 1px solid  gray;
  }
  th{
    height:5rem;
    font-size: 1.8rem;
    width:10%;
    background-color: #f4f4f4;
  }
  td{
    height:5rem;
    text-align:center;
    vertical-align:middle;
    background-color: #ffffff;
  }
  .btn_more{margin-top: 5%;
    border:0.1rem solid #00ec03;
    color: #ffffff;
    box-shadow: 0 0 0.1rem #00ec03;
    background: repeating-linear-gradient(to right, #00d7f6 , #00ec03 100%);
    /*background: linear-gradient(to right, #00d7f6 , #00ec03); !* 标准的语法 *!*/
  }
  div.btn_more:hover{
    box-shadow: 0 0 0.4rem #00ec03;
    color: #ffffff;
  }
  .qingke_footer{
    background-color: #222222;
    margin-top: 1%;
  }
  .qingke_footer_word>p:nth-child(1){
    font-size: 1.4rem;
    color: #ffffff;
  }
  .qingke_footer_word>p{
    color: #ffffff;
  }
  .convention_bottom{
    font-size: 1.4rem;
  }
  .constant>p{
    margin-top: 0.5rem;
  }
  .click-more .el-dialog, .el-pager li{
    background-color: rgba(34,34,34,0.95);
  }
  .sleep-word{
    font-size: 5rem;
    color: #ffffff;
    margin: 5% 0;
  }
  .word-min{
    font-size: 2rem;
    color: #FCD281;
  }
  .sleep{
    height:15rem;
    width:15rem;
  }
  .sleep-left>img{
    height: 12rem;
    width:12rem;
  }
  .sleep-footer{
    display: flex;
    margin: 5% 0;
    justify-content: flex-start;
  }
  .sleep-right{
    position: relative;
    top:5rem;
    left: 4%;
  }
  .sleep-right>p{
    color: #ffffff;
    font-size:1.8rem;
  }
  @media screen and (max-width:640px){

  .el-dialog__body{
    	padding:0!important;
 	}
	 .click-more span{
		 margin-top:5%!important;
	 }

	 .v-alert-main{
		  width:100%;
		left:0;
		float:none;
		padding:0 10px;
	 }
	  
	 .v-alert-main img.sleep {
		 padding:10px 0;
		 width:30%;
		 height:auto;
		 margin:0 auto;
		 display:block;
	 }
	 .el-dialog__title{
		 display:none;
	 }
}
</style>

