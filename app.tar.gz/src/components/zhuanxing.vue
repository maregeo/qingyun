<template lang="html">
    <div class="zhuanxing">
      <div class="zhuanxing-top">
          <div><img src="../assets/images/minzhuan.png" alt=""></div>
          <div>前沿转型系列</div>
        </div>
        <div class="content">
          <table  border="0" cellspacing="0" cellpadding="0">
            <tr>
              <th class="left">主题</th>
              <th>天数</th>
              <th>往期学员</th>
              <th class="right">上榜理由</th>
            </tr>
            <tr>
              <td class="main-head">让HR推动经营—像CEO一样思考</td>
              <td>2</td>
              <td class="left-center">搜狐、360、酒仙网、江中药业、大唐电信、新东方、阿里巴巴、雅迪科技、浦发银行、德州银行、上汽、苏泊尔、贝因美、德力西电气、GE、施耐德、TCL、汤臣倍健股份有限公司、瑞声科技、四川航空股份有限公司、中信银行、珍爱网… …</td>
              <td class="lastCol">解读业务有诸多视角，但无论万般变化，老板眼中的业务就是“生意”。你可能需要一个经营思维导图、一套经营工具、若干人力资源管理“抓手”、若干人力资源管理方案。GHR重磅打造《让HR推动经营-像CEO一样思考》，带HR一起变身业务推手、成为老板心腹。</td>
            </tr>
            <tr>
              <td class="main-head">用数据驱动人力资源效能提升</td>
              <td>2</td>
              <td class="left-center">一汽大众、搜狐、360、酒仙网、江中药业、大唐电信、新东方、阿里巴巴、雅迪科技、浦发银行、德州银行、上汽、苏泊尔、贝因美、德力西电气、GE、施耐德、雅居乐、中国联通、东风汽车、明治雪糕、百事可乐、顺丰速运、药明康德、延长壳牌（四川）石油有限公司、西门子、九牧厨卫、苏宁、万科、泰康人寿、国家电网……</td>
              <td class="lastCol">一方面，HR在抱怨老板们看不到自己的价值，缺乏存在感，却很难说清自己对战略有什么贡献，只有坚守“人力资源管理是固本强基，必不可少”的逻辑；另一方面，在激烈的市场竞争环境下，老板们却没有这么好的耐心，开始向HR们直接要结果——贡献究竟在哪里？
时代变了，HR们也要改变自己的生存逻辑，只有这样才能“与业务共舞”。<br>
本课程基于穆胜博士多年的理论研究和实践验证，涉及方法论具备强劲的逻辑基础；
案例来源于实践，讲授方法无缝对接实践。拒绝炫技，力图实操！
基于案例讲授方法，以“企业剧场”辅导运用，把课堂变成“教练场”，力求让学员打够热身赛，能够“走出课堂即可上手”。</td>
            </tr>
            <tr>
              <td class="main-head">股权激励体系方案设计班</td>
              <td>2</td>
              <td class="left-center">淘宝、兴业证券、农业银行、格林豪泰、上汽集团、正和岛、七匹狼、万声通讯、呷哺呷哺、上海广播电影电视、人人猎头、三一重工、柳工、益邦物流、国海证券、博康智能、长江财富、福州大学、银联、百事通、红星美凯龙、华南药业、中广核集团、永和食品、中原地产、爱数软件、滔博体育、通得电气…</td>
              <td class="lastCol">从名企和成长型企业案例入手，对整个人才激励体系进行剖析，学习使用多种激励方式，现场产出三大成果：<br>
A企业激励策略分析报告；
B非上市公司的两种激励方案择其一（业绩计划、虚拟股权）；
C上市公司的两种激励方案择其一（限制性股票、股票期权）。专家手把手辅导、深入点评、现场产出三大成果，方案接地气拿回去即可参考使用。</td>
            </tr>
            <tr>
              <td class="main-head">华为式人才培养与商学院建设</td>
              <td>2</td>
              <td class="left-center">广汽研究院、吉利汽车研究院、新华人寿、水井坊、亮创集团、无限极、好孩子、星火教育、步步高置业、南宁百货大楼、江苏国贸减速机、迈瑞医疗、南京天脉、天港控股、江苏有线数据网络、中海物业、蜀海（北京）食品有限公司、万科链家、竞技世界、中国石化石油勘探开发研究院、光大银行、特变电工、贝登医疗、中国电子系统工程第四建设有限公司、、广西柳工……</td>
              <td class="lastCol">企业最核心的竞争力是什么？人才，不是！是对人才的培养和管理。
企业孵化人才的速度才是真正的核心竞争力，如何科学高效的培养后备人才队伍，如何向华为一样让优秀的人培养更优秀的人。<br>
本课程系统总结了华为公司人才培养体系，特别在企业如何突破发展与人才紧缺的困境，如何专业的搭建内部的人才生产线，人才继任中如何有效的展开干部梯队建设；以及新时代背景下，企业商学院的强大功能如何助推企业变革与升级，大量的实操案例与经验沉淀，专业覆盖下的深入浅出的分享 。</td>
            </tr>
            <tr>
              <td class="main-head">重新定义绩效管理：<br>敏捷化创新与变革实战</td>
              <td>2</td>
              <td class="left-center">东风汽车、东软集团、中国石油股份、TCL、青岛啤酒、振杰国际、创维集团、徐工集团、三一重工、中国移动、河南移动、宁波成路集团、东风雪铁龙、中国电信、广州西婷化妆品、万家乐燃气热水器、南方李锦记、首信集团、光明维他奶......</td>
              <td class="lastCol">传统绩效管理每年做一次，低效僵化。敏捷化开始渗透在业务中，如何重塑绩效管理，学会运用简单的模型，将绩效管理侧重在反馈辅导、目标设定和员工与经理的友好关系上？
本课程结合国际最新绩效管理理念，融入老师多年本土企业实践经验,并且创新模型已被中国国家版权机构认证。<br>该课程将为您提供一个全新的方法进行绩效管理，帮助您的企业在互联网环境下取得战略成功。</td>
            </tr>
          </table>
        </div>
		<footer-bar></footer-bar>
        <!--
		<div class="qingke_footer">
          <el-row>
          <el-col :span="16">
            <el-row>
              <el-col :span="24"><div class="grid-content">
              <div>
                  <img src="../assets/images/qingke.png" alt="">
               </div>
              </div></el-col>
            </el-row>
           </el-col>
        </el-row>
        <el-row>
          <el-col :span="16">
            <el-row type="flex" justify="space-around">
              <el-col :span="24"><div class="grid-content qingke_footer_word">
              <p>运营机构 : </p>
              <p>氢课（上海）教育科技有限公司</p>
              </div></el-col>

              <el-col :span="24"><div class="grid-content qingke_footer_word">
              <p>售前售后 :</p>
              <p><img src="../assets/images/weiXin.png" alt=""></p>
              <p>GHRVIP13</p>
              <p><img src="../assets/images/weiXin.png" alt=""></p>
              <p>TV@Ghrlib.com</p>
              </div></el-col>

              <el-col :span="24"><div class="grid-content qingke_footer_word">
              <p>市场合作：</p>
              <p><img src="../assets/images/weiXin.png" alt=""></p>
              <p>Marketing@ghrlib.com</p>
              </div></el-col>

              <el-col :span="24"><div class="grid-content qingke_footer_word">
              <p>讲师合作：</p>
              <p><img src="../assets/images/weiXin.png" alt=""></p>
              <p>GHRVIP1</p>
              </div></el-col>
              <el-col :span="24"><div class="grid-content qingke_footer_word">
              <p>热线电话：</p>
              <p><img src="../assets/images/weiXin.png" alt=""></p>
              <p>400-696-2298</p>
              <p></p>
              </div></el-col>
              <el-col :span="24"><div class="grid-content qingke_footer_word">
              <p>官方微信：</p>
              <p><img src="../assets/images/weiXin.png" alt=""></p>
              <p>Qkercom</p>
              <p><img src="../assets/images/weiXin.png" alt=""></p>
              </div></el-col>
            </el-row>
           </el-col>
        </el-row>
        </div>
		-->
    </div>
</template>

<script>
import footerBar from './footer_bar' //导入组件
export default {
	components: {
    	footerBar: footerBar //注册组件
  	},
}
</script>

<style lang="css" scoped>
  .zhuanxing-top{
    font-size: 3rem;
    padding-top: 8%;
    text-align: center;
  }
  .zhuanxing-top>div{
    display: inline-block;
    vertical-align: middle;
  }
  .content{
    text-align: center;
    width:50%;
    margin: 0 auto;
    padding-bottom: 10rem;
    box-shadow: 0.5rem 0.5rem 1rem #f2f2f2;
  }

  .content>p:nth-child(1){
    font-size: 3rem;
  }
  table {
    border-collapse: collapse;
    width:100%;
    margin: 0 auto;
    margin-top: 3%;
    border: 0px solid #999;
  }
  table td {
    border-top: 0;
    border-right: 1px solid #999;
    border-bottom: 1px solid #999;
    border-left: 0;
  }

  .content table{
    border-left:none;
    border-right:none;
    border: none;
  }
  th{
    border: 1px solid #565656;
    border-top:none;
    background-color: #f2f2f2;
    font-size: 2.5rem;
  }
  .left{
    border-left: none;
  }
  .right{
    border-right: none;
  }
  table tr td.lastCol {
    border-right: 0;
    text-align: left;
  }
  .left-center{
    text-align: left;
  }
  .main-head{
    font-size: 1.8rem;
    padding:1rem 2rem;
    width:37%;
  }
  tr,td{
    min-height:6rem;
    font-size: 1.2rem;
    padding:1rem 2rem;
  }
  .qingke_footer{
    background-color: #222222;
    margin-top: 5%;
  }
  .qingke_footer_word>p:nth-child(1){
    font-size: 1.4rem;
    color: #ffffff;
  }
  .qingke_footer_word>p{
    color: #ffffff;
  }
   @media screen and (max-width:640px){
	  .zhuanxing-top{
			padding-top:0;
	  }
    .content{
      width:100%;
      box-sizing:border-box;
	  padding:10px;
    }
    .content table tr{
      padding:0;
    }
    .content table th{
        height:30px;
        line-height:30px;
    }
    .content table td{
     	width:20%;
      	padding:0 3px;
    }
     .content table td:nth-child(1){
		 width:15%;
     }
     .content table td:nth-child(2){
       width:10%;
     }
    .main-head{
      width:100%;
     
    }
  }
</style>
