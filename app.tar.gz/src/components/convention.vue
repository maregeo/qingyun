<template lang="html">
    <div class="convention">
        <el-row>
          <el-col :span="24"><div class="grid-content bg-purple-dark">
              <img src="../assets/images/HZ.jpg" class="v-success-img"/>
            <!--<img src="../assets/images/a1.jpg" alt="" style="width:100%; height: 100vh;">-->
            <div class="v-convention-wrapp">
				<div class="v-convention-auto">
					<p>氢云会展</p>
					<p>氢学堂构建了以SAAS平台为载体， 培训咨询为支撑，兼顾运营效率与 成果落地的一体化企业移动大学解 决方案体系。</p>
				</div>
            </div>
            <el-row class="qingKe_top">
          <el-col :span="1"><div class="grid-content bg-purple-light"></div></el-col>
          <el-col :span="5"><div class="qingKe_top_left" style="text-align:center;">氢云会展</div></el-col>
          <el-col :span="18"><div class="qingKe_top_right">
            <div>关于氢云会展</div>
            <div>产品介绍</div>
            <div >产品优势</div>
          </div></el-col>

        </el-row>
          </div></el-col>
        </el-row>
        <el-row>
          <el-col :span="24"><div class="grid-content bg-purple-dark" >
            <div class="sy_car_third">
              <p>关于氢云会展 </p>
              <p>氢云会展结合了人力资源行业优秀品牌产品， 了解市场最新服务成果，促进人力资源从业者与优秀人力 资源产品的完美结合，以推动中国企业人力资源效能提升和组织转型。</p>
            </div>
          </div></el-col>
          <el-col :span="24">
            <div class="grid-content qingKePhone" style="text-align: center ">
              <img src="../assets/images/mac.png" alt="" style="width: 40%;">
            </div>
          </el-col>
        </el-row>
        <div class="sy_car_second">
        <p>产品介绍 </p>
        <p style="margin-bottom: 1rem">氢云会展结合了人力资源行业优秀品牌产品， 了解市场最新服务成果，促进人力资源从业者与优秀人力 资源产品的完美结合，以推动中国企业人力资源效能提升和组织转型。</p>
        <el-row >
          <el-col :span="12" :push="6" class="v-vonvention-list">
            <el-row class="">
              <el-col :span="24">
                    <table>
                      <tr>
                        <th>时间</th>
                        <th>大会名称</th>
                        <th>分享主题</th>
                      </tr>
                      <tr>
                        <td>2017年10月23日——10月26日</td>
                        <td>2017（中国）优秀人力资源产品展</td>
                        <td>汇聚8+优秀HR机构最新研究成果 8大主题 8位分享嘉宾：魏一凡、田之富、赵永标、张珂等</td>
                      </tr>
                      <tr>
                        <td>2017年12月31日前</td>
                        <td>2017中国人力资源实践创新（企业）评选</td>
                        <td></td>
                      </tr>
                      <tr>
                        <td >2017年11月25日-26日</td>
                        <td>2017（第十届）中国人力资源管理年会</td>
                        <td>2007-2017：中国企业管理“进化论”</td>
                      </tr>
                      <tr>
                        <td>2018年1月5日</td>
                        <td>第三届中国行动学习论坛暨管理学院院长论坛</td>
                        <td>“敏捷共创”教学法——VUCA时代线下教学创新</td>
                      </tr>
                    </table>
              </el-col>
            </el-row>
          </el-col>
        </el-row>
      </div>
      	<el-row>
          	<el-col :span="24">
		  		<div class="grid-content bg-purple-dark" >
            		<div class="sy_car_third">
						<p>产品优势 </p>
						<el-row>
							<el-col :span="10" :push="8" class="v-cont-item">
							<span><img src="../assets/images/star.png" alt=""></span>
							<span class="convention_content_word">汇聚人力资源行业内各领域领先优秀服务商；</span>
							</el-col>
						</el-row>
						<el-row>
							<el-col :span="8" :push="8" class="v-cont-item">
							<span><img src="../assets/images/star.png" alt=""></span>
							<span class="convention_content_word">最新的行业趋势、干货分享、案例解析；</span>
						</el-col>
					</el-row>
              <el-row>
                <el-col :span="8" :push="8" class="v-cont-item">
                  <span><img src="../assets/images/star.png" alt=""></span>
                  <span class="convention_content_word">超高质量的服务、产品、解决方案等。</span>
                </el-col>
              </el-row>
              <el-row>
                <el-col :span="8" :push="8" class="v-cont-item">
                 <span><img src="../assets/images/star.png" alt=""></span>
                  <span class="convention_content_word v-test">结dqwq合人力资源行业优秀品牌产品，了解市场 最新服务成果，促进人力资源从业者与优秀 人力资源产品的完美结合，以推动中国企业 人力资源效能提升和组织转型。</span>
                </el-col>
              </el-row>
              <el-row>
                <el-col :span="8" :push="8" class="v-cont-item"><div class="grid-content good" >
                  <img src="../assets/images/good.png" alt="" style="width:60%;">
                </div></el-col>
              </el-row>
            </div>
          </div></el-col>
        </el-row>
		 <footer-bar></footer-bar>
		<!--
        <div class="qingke_footer">
          <el-row>
          <el-col :span="16" :push="4">
            <el-row>
              <el-col :span="24"><div class="grid-content">
              <div>
                  <img src="../assets/images/logo.png" alt="" style="height: 5rem;width:rem;padding-top: 2rem">
               </div>
              </div></el-col>
            </el-row>
           </el-col>
        </el-row>
        <el-row>
          <el-col :span="16" :push="4">
            <el-row type="flex" justify="space-around">
              <el-col :span="24"><div class="grid-content qingke_footer_word">
              <p>
              <span><img src="" alt=""></span>
              <span class="convention_bottom">175 66666 666</span>
              </p>
              <p>
              <span><img src="" alt=""></span>
              <span class="convention_bottom">上海市 长宁区</span>
              </p>
              <p>
              <span><img src="" alt=""></span>
              <span class="convention_bottom">GHRLIB@XX.COM</span>
              </p>
              </div></el-col>

              <el-col :span="24"><div class="grid-content qingke_footer_word">
              <p>旗下品牌：</p>
              <p>
                <span><img src="../assets/images/weiXin.png" alt="" style="height: 2rem;width:3rem;"></span>
                <span><img src="../assets/images/weiXin.png" alt="" style="height: 2rem;width:3rem;"></span>
              </p>
              <p>
                <span><img src="../assets/images/weiXin.png" alt="" style="height: 2rem;width:3rem;"></span>
                <span><img src="../assets/images/weiXin.png" alt="" style="height: 2rem;width:3rem;"></span>
              </p>
              <p>
                <span><img src="../assets/images/weiXin.png" alt="" style="height: 2rem;width:3rem;"></span>
                <span><img src="../assets/images/weiXin.png" alt="" style="height: 2rem;width:3rem;"></span>
              </p>
              </div></el-col>

              <el-col :span="24"><div class="grid-content qingke_footer_word">
              <p>在线学习：</p>
              <p><img src="../assets/images/weiXin.png" alt=""></p>
              <p><img src="../assets/images/weiXin.png" alt=""></p>
              <p><img src="../assets/images/weiXin.png" alt=""></p>
              </div></el-col>
              <el-col :span="24"><div class="grid-content qingke_footer_word constant">
              <p>联系电话：</p>
              <p>培训业务</p>
              <p>微咨询</p>
              <p>在线学习</p>
              <p>广告合作</p>
              <p>市场合作</p>
              <p>加入我们</p>
              </div></el-col>
              <el-col :span="24"><div class="grid-content qingke_footer_word">
              <p>市场合作：</p>
              <p>市场合作：</p>
              </div></el-col>
            </el-row>
           </el-col>
        </el-row>
        </div>
		-->
    </div>
</template>

<script>
import footerBar from './footer_bar' //导入组件
export default {
	components: {
    	footerBar: footerBar //注册组件
  	}
}
</script>

<style lang="css" scoped>
.v-success-img{
		width:100%;
	}
	.v-convention-wrapp{
		position: absolute;
		top:0;
		left:0;
		bottom:0;
		width:100%;
	}
	.v-convention-auto{
		width:30%;
		margin:20%  auto 0;
	}

	.v-convention-auto p:first-child{
		font-size: 6rem;
    	color: #ffffff;
   	}
	.v-convention-auto  p:nth-child(2){
		font-size: 2rem;
   		color: red;
	}
	.convention_top{
		height:100vh;
		width:100%;
		background-image: url("../assets/images/HZ.jpg");
		background-size: 100% 100%;
  	}
  .convention_top>p:nth-child(1){
    font-size: 6rem;
    color: #ffffff;
    position: absolute;
    top:35%;
    left: 30%;
  }
  .convention_top>p:nth-child(2){
    font-size: 2rem;
    width:25%;
    position: absolute;
    color: red;
    top:45%;
    left: 30%;
  }
  .convention_top>p:nth-child(3){
    color: #ffffff;
    font-size: 3rem;
    position: absolute;
    top:70%;
    left: 30%;
    left: 30%;
    vertical-align: top;
  }
  .qingKe_top{
    position: relative;
    background-color: #f4f4f4;
    height: 6rem;
    line-height: 6rem;
    border-bottom: 0.1rem solid gray;
    top:95%;
    z-index: 666;
  }
  .qingKe_top_left{
    font-size: 3rem;
    font-weight: 600;
  }
  .qingKe_top_right{
    display: flex;
    margin-top: 2rem;
  }
  .qingKe_top_right>div{
    text-align: center;
    width:30%;
    line-height: 2rem;
    font-size: 1.4rem;
    height: 2rem;
    border-right: 0.1rem solid gray;
    justify-content: space-around;
  }
  table {
    width:100%;
    border-collapse: collapse;
    margin-bottom: 5rem;
  }
  table,th, td
  {
    border: 1px solid  gray;
  }
  th{
    height:5rem;
    font-size: 1.8rem;
    width:30%;
    background-color: #f4f4f4;
  }
  td{
    height:5rem;
    text-align:center;
    vertical-align:middle;
    background-color: #ffffff;
  }
  .convention_content_word{
    font-size: 2rem;
    color: #99a9bf;
  }
  .qingke_footer{
    background-color: #222222;
  }
  .qingke_footer_word>p:nth-child(1){
    font-size: 1.4rem;
    color: #ffffff;
  }
  .qingke_footer_word>p{
    color: #ffffff;
  }
  .convention_bottom{
  font-size: 1.6rem;
  }
  .constant>p{
    margin-top: 0.5rem;
  }
  .sy_car_third{
    text-align: left;
  }
  .sy_car_third span{
    display: inline-block;
    vertical-align: middle;
  }
  .good{
    text-align: center;
  }
  .v-test{
	  margin-left: 6.5rem;
	  margin-top: -3.8rem
  }
   	@media screen and (max-width:640px){
		.v-test{
			margin-left:0;
			margin-top:0;
		}
       	.v-convention-wrapp{
			display:none;
       	}
		.sy_car_third>p:nth-child(2){
			width:80%;
			margin:0 auto;
			line-height:18px;
		}
		.sy_car_second>p:nth-child(2){
			width:80%;
			margin:0 auto;
			line-height:18px;
		}
		.v-vonvention-list{
			padding:0 10px;
			width:100%;
			left:0;
		}
		.v-vonvention-list table{
			margin-bottom:0px;
		}
		.v-cont-item{
			width:90%;
			left:0;
			margin:0 auto;
			float:none;
		}
		.v-cont-item span{
			display:block;
			line-height:15px;
		}
		.v-cont-item span:first-child{
			float:left;
		}
		.v-cont-item span:nth-child(2){
			padding-left:30px;
		}
		.v-cont-item img{
			width:15px;

		}
		.good img{
			width:80px!important;
		}
     }
</style>
