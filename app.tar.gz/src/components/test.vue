<template lang="html">
    <div class="test">
        路由跳转测试
    </div>
</template>

<script>
export default {}
</script>

<style lang="css" scoped>
</style>
